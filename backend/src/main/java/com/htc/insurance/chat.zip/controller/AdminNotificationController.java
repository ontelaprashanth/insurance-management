package com.htc.insurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.htc.insurance.dto.AdminNotificationRequest;
import com.htc.insurance.dto.AdminNotificationResponse;
import com.htc.insurance.dto.NotificationDto;
import com.htc.insurance.entity.User;
import com.htc.insurance.service.AdminNotificationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/admin/notifications")
@PreAuthorize("hasRole('ADMIN')")
public class AdminNotificationController {

    @Autowired
    private AdminNotificationService
            adminNotificationService;


    // =========================================================
    // SEND NOTIFICATION
    // =========================================================

    @PostMapping
    public ResponseEntity<AdminNotificationResponse>
    sendNotification(
            @Valid
            @RequestBody
            AdminNotificationRequest request) {

        return ResponseEntity.ok(
                adminNotificationService
                        .sendNotification(request));
    }


    // =========================================================
    // GET CUSTOMERS
    // =========================================================

    @GetMapping("/customers")
    public ResponseEntity<List<User>>
    getCustomers() {

        return ResponseEntity.ok(
                adminNotificationService
                        .getCustomers());
    }


    // =========================================================
    // GET ADMIN NOTIFICATION HISTORY
    // =========================================================

    @GetMapping
    public ResponseEntity<List<NotificationDto>>
    getHistory() {

        return ResponseEntity.ok(
                adminNotificationService
                        .getAdminNotificationHistory());
    }


    // =========================================================
    // DELETE ADMIN NOTIFICATION
    // =========================================================

    @DeleteMapping("/{notificationId}")
    public ResponseEntity<String>
    deleteNotification(
            @PathVariable Long notificationId) {

        adminNotificationService
                .deleteAdminNotification(
                        notificationId);

        return ResponseEntity.ok(
                "Admin notification deleted successfully.");
    }
}