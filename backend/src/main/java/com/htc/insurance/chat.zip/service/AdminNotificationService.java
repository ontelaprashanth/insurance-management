package com.htc.insurance.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.htc.insurance.dto.AdminNotificationRequest;
import com.htc.insurance.dto.AdminNotificationResponse;
import com.htc.insurance.dto.NotificationDto;
import com.htc.insurance.entity.Notification;
import com.htc.insurance.entity.User;
import com.htc.insurance.repository.NotificationRepository;
import com.htc.insurance.repository.UserRepository;

@Service
public class AdminNotificationService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private NotificationService notificationService;


    private static final Set<String> ALLOWED_TYPES =
            Set.of(
                    "OFFER",
                    "ANNOUNCEMENT",
                    "ALERT",
                    "GENERAL",
                    "PAYMENT",
                    "POLICY"
            );


    private static final Set<String> ALLOWED_RECIPIENTS =
            Set.of(
                    "ALL",
                    "USER"
            );


    // =========================================================
    // SEND NOTIFICATION
    // =========================================================

    public AdminNotificationResponse sendNotification(
            AdminNotificationRequest request) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Notification data is required.");
        }


        // =====================================================
        // VALIDATE TITLE
        // =====================================================

        if (request.getTitle() == null ||
                request.getTitle().isBlank()) {

            throw new IllegalArgumentException(
                    "Notification title is required.");
        }


        // =====================================================
        // VALIDATE MESSAGE
        // =====================================================

        if (request.getMessage() == null ||
                request.getMessage().isBlank()) {

            throw new IllegalArgumentException(
                    "Notification message is required.");
        }


        // =====================================================
        // TYPE
        // =====================================================

        String type =
                request.getType()
                        .trim()
                        .toUpperCase();

        if (!ALLOWED_TYPES.contains(type)) {

            throw new IllegalArgumentException(
                    "Invalid notification type. Allowed types: "
                            + ALLOWED_TYPES);
        }


        // =====================================================
        // RECIPIENT TYPE
        // =====================================================

        String recipientType =
                request.getRecipientType()
                        .trim()
                        .toUpperCase();

        if (!ALLOWED_RECIPIENTS.contains(
                recipientType)) {

            throw new IllegalArgumentException(
                    "Invalid recipient type. Use ALL or USER.");
        }


        int recipientCount = 0;


        // =====================================================
        // SEND TO ALL CUSTOMERS
        // =====================================================

        if ("ALL".equals(recipientType)) {

            List<User> users =
                    userRepository.findAll();

            for (User user : users) {

                if (user == null) {
                    continue;
                }

                if (user.getUserId() == null) {
                    continue;
                }

                if (!"USER".equalsIgnoreCase(
                        user.getRole())) {

                    continue;
                }

                if (Boolean.FALSE.equals(
                        user.getIsActive())) {

                    continue;
                }


                notificationService
                        .createAdminNotification(
                                user,
                                request.getTitle(),
                                request.getMessage(),
                                type
                        );

                recipientCount++;
            }
        }


        // =====================================================
        // SEND TO SPECIFIC CUSTOMER
        // =====================================================

        else {

            if (request.getUserId() == null) {

                throw new IllegalArgumentException(
                        "Customer user ID is required.");
            }


            User user =
                    userRepository.findById(
                            request.getUserId())
                            .orElseThrow(() ->
                                    new IllegalArgumentException(
                                            "Customer not found: "
                                                    + request.getUserId()
                                    )
                            );


            if (!"USER".equalsIgnoreCase(
                    user.getRole())) {

                throw new IllegalArgumentException(
                        "Notifications can only be sent to customers.");
            }


            if (Boolean.FALSE.equals(
                    user.getIsActive())) {

                throw new IllegalArgumentException(
                        "Selected customer account is inactive.");
            }


            notificationService
                    .createAdminNotification(
                            user,
                            request.getTitle(),
                            request.getMessage(),
                            type
                    );

            recipientCount = 1;
        }


        return new AdminNotificationResponse(
                "Notification sent successfully.",
                recipientCount
        );
    }


    // =========================================================
    // GET CUSTOMERS
    // =========================================================

    public List<User> getCustomers() {

        return userRepository.findAll()
                .stream()
                .filter(user ->
                        user != null
                        && "USER".equalsIgnoreCase(
                                user.getRole()))
                .filter(user ->
                        !Boolean.FALSE.equals(
                                user.getIsActive()))
                .toList();
    }


    // =========================================================
    // ADMIN NOTIFICATION HISTORY
    // =========================================================

    public List<NotificationDto>
    getAdminNotificationHistory() {

        return notificationRepository
                .findBySourceOrderByCreatedAtDesc("ADMIN")
                .stream()
                .map(this::mapToDto)
                .toList();
    }


    // =========================================================
    // DELETE ADMIN NOTIFICATION
    // =========================================================

    public void deleteAdminNotification(
            Long notificationId) {

        Notification notification =
                notificationRepository
                        .findById(notificationId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Notification not found: "
                                                + notificationId
                                )
                        );


        if (!"ADMIN".equalsIgnoreCase(
                notification.getSource())) {

            throw new IllegalArgumentException(
                    "Only admin notifications can be deleted here.");
        }


        notificationRepository.delete(
                notification);
    }


    // =========================================================
    // ENTITY → DTO
    // =========================================================

    private NotificationDto mapToDto(
            Notification notification) {

        NotificationDto dto =
                new NotificationDto();

        dto.setNotificationId(
                notification.getNotificationId());

        if (notification.getUser() != null) {

            dto.setUserId(
                    notification.getUser().getUserId());
        }

        dto.setTitle(
                notification.getTitle());

        dto.setMessage(
                notification.getMessage());

        dto.setType(
                notification.getType());

        dto.setIsRead(
                notification.getIsRead());

        dto.setCreatedAt(
                notification.getCreatedAt());

        dto.setSource(
                notification.getSource());

        return dto;
    }
}