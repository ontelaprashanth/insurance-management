package com.htc.insurance.service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.htc.insurance.dao.PolicyDao;
import com.htc.insurance.dao.PolicyHolderDao;
import com.htc.insurance.dao.UserDao;
import com.htc.insurance.dto.PolicyDto;
import com.htc.insurance.entity.Policy;
import com.htc.insurance.entity.PolicyHolder;
import com.htc.insurance.entity.User;
import com.htc.insurance.mapper.PolicyMapper;

@Service
public class PolicyService {

    @Autowired
    private PolicyDao policyDao;

    @Autowired
    private PolicyHolderDao policyHolderDao;

    @Autowired
    private PolicyMapper policyMapper;

    @Autowired
    private UserDao userDao;

    @Autowired
    private NotificationService notificationService;


    // =========================================================
    // SAVE POLICY
    // =========================================================

    public PolicyDto savePolicy(PolicyDto policyDto) {

        if (policyDto == null) {
            throw new RuntimeException(
                    "Policy details are required.");
        }

        if (policyDto.getPolicyHolderId() == null) {
            throw new RuntimeException(
                    "Policy holder is required.");
        }

        if (policyDto.getStartDate() == null) {
            throw new RuntimeException(
                    "Policy start date is required.");
        }

        Integer durationYears =
                policyDto.getDurationYears();

        if (durationYears == null || durationYears <= 0) {
            throw new RuntimeException(
                    "Policy duration must be greater than zero.");
        }

        PolicyHolder policyHolder =
                policyHolderDao.getPolicyHolderById(
                        policyDto.getPolicyHolderId());

        if (policyHolder == null) {
            throw new RuntimeException(
                    "Policy holder not found.");
        }

        LocalDate expiryDate =
                policyDto.getStartDate()
                        .plusYears(durationYears);

        Policy policy =
                policyMapper.convertPolicyDtoToEntity(
                        policyDto);

        policy.setPolicyHolder(policyHolder);
        policy.setStartDate(policyDto.getStartDate());
        policy.setExpiryDate(expiryDate);
        policy.setIsActive(Boolean.TRUE);

        Policy savedPolicy =
                policyDao.savePolicy(policy);


        // =====================================================
        // NOTIFICATION - POLICY CREATED
        // =====================================================

        createPolicyNotification(
                policyHolder,
                "Policy Created",
                "Your insurance policy #"
                        + savedPolicy.getPolicyNumber()
                        + " has been created successfully.",
                "POLICY"
        );


        return policyMapper.convertPolicyEntityToDto(
                savedPolicy);
    }


    // =========================================================
    // GET ALL POLICIES
    // =========================================================

    public List<PolicyDto> getAllPolicies() {

        return policyDao.getAllPolicies()
                .stream()
                .map(policyMapper::convertPolicyEntityToDto)
                .collect(Collectors.toList());
    }


    // =========================================================
    // GET POLICY BY ID
    // =========================================================

    public PolicyDto getPolicyById(
            Long policyNumber) {

        if (policyNumber == null) {
            throw new RuntimeException(
                    "Policy number is required.");
        }

        Policy policy =
                policyDao.getPolicyById(policyNumber);

        if (policy == null) {
            return null;
        }

        return policyMapper.convertPolicyEntityToDto(
                policy);
    }


    // =========================================================
    // UPDATE POLICY
    // =========================================================

    public PolicyDto updatePolicy(
            Long policyNumber,
            PolicyDto policyDto) {

        if (policyNumber == null) {
            throw new RuntimeException(
                    "Policy number is required.");
        }

        if (policyDto == null) {
            throw new RuntimeException(
                    "Policy details are required.");
        }

        Policy existingPolicy =
                policyDao.getPolicyById(policyNumber);

        if (existingPolicy == null) {
            return null;
        }

        if (policyDto.getPolicyHolderId() == null) {
            throw new RuntimeException(
                    "Policy holder is required.");
        }

        if (policyDto.getStartDate() == null) {
            throw new RuntimeException(
                    "Policy start date is required.");
        }

        Integer durationYears =
                policyDto.getDurationYears();

        if (durationYears == null || durationYears <= 0) {
            throw new RuntimeException(
                    "Policy duration must be greater than zero.");
        }

        PolicyHolder policyHolder =
                policyHolderDao.getPolicyHolderById(
                        policyDto.getPolicyHolderId());

        if (policyHolder == null) {
            throw new RuntimeException(
                    "Policy holder not found.");
        }

        LocalDate expiryDate =
                policyDto.getStartDate()
                        .plusYears(durationYears);

        Policy updatedPolicy =
                policyMapper.convertPolicyDtoToEntity(
                        policyDto);


        // -----------------------------------------------------
        // Preserve policy number
        // -----------------------------------------------------

        updatedPolicy.setPolicyNumber(
                existingPolicy.getPolicyNumber());


        // -----------------------------------------------------
        // Preserve active/inactive status
        // -----------------------------------------------------

        updatedPolicy.setIsActive(
                existingPolicy.getIsActive());


        updatedPolicy.setPolicyHolder(
                policyHolder);

        updatedPolicy.setStartDate(
                policyDto.getStartDate());

        updatedPolicy.setExpiryDate(
                expiryDate);


        Policy savedPolicy =
                policyDao.updatePolicy(
                        updatedPolicy);


        // =====================================================
        // NOTIFICATION - POLICY UPDATED
        // =====================================================

        createPolicyNotification(
                savedPolicy.getPolicyHolder(),
                "Policy Updated",
                "Your insurance policy #"
                        + savedPolicy.getPolicyNumber()
                        + " has been updated successfully.",
                "POLICY"
        );


        return policyMapper.convertPolicyEntityToDto(
                savedPolicy);
    }


    // =========================================================
    // DELETE POLICY
    // =========================================================

    public void deletePolicy(
            Long policyNumber) {

        if (policyNumber == null) {
            throw new RuntimeException(
                    "Policy number is required.");
        }

        Policy policy =
                policyDao.getPolicyById(
                        policyNumber);

        if (policy == null) {
            throw new RuntimeException(
                    "Policy not found.");
        }


        // -----------------------------------------------------
        // Do not allow deletion if claims exist
        // -----------------------------------------------------

        if (policy.getClaims() != null
                && !policy.getClaims().isEmpty()) {

            throw new RuntimeException(
                    "Policy cannot be deleted because it has claims.");
        }


        // -----------------------------------------------------
        // Store holder before deleting
        // -----------------------------------------------------

        PolicyHolder policyHolder =
                policy.getPolicyHolder();


        // -----------------------------------------------------
        // Delete policy
        // -----------------------------------------------------

        policyDao.deletePolicy(policyNumber);


        // =====================================================
        // NOTIFICATION - POLICY DELETED
        // =====================================================

        createPolicyNotification(
                policyHolder,
                "Policy Deleted",
                "Your insurance policy #"
                        + policyNumber
                        + " has been deleted successfully.",
                "POLICY"
        );
    }


    // =========================================================
    // ACTIVATE POLICY
    // =========================================================

    public PolicyDto activatePolicy(
            Long policyNumber) {

        if (policyNumber == null) {
            throw new RuntimeException(
                    "Policy number is required.");
        }

        Policy policy =
                policyDao.getPolicyById(
                        policyNumber);

        if (policy == null) {
            throw new RuntimeException(
                    "Policy not found.");
        }

        policy.setIsActive(Boolean.TRUE);

        Policy updatedPolicy =
                policyDao.updatePolicy(policy);


        // =====================================================
        // NOTIFICATION - POLICY ACTIVATED
        // =====================================================

        createPolicyNotification(
                updatedPolicy.getPolicyHolder(),
                "Policy Activated",
                "Your insurance policy #"
                        + updatedPolicy.getPolicyNumber()
                        + " has been activated.",
                "POLICY"
        );


        return policyMapper.convertPolicyEntityToDto(
                updatedPolicy);
    }


    // =========================================================
    // DEACTIVATE POLICY
    // =========================================================

    public PolicyDto deactivatePolicy(
            Long policyNumber) {

        if (policyNumber == null) {
            throw new RuntimeException(
                    "Policy number is required.");
        }

        Policy policy =
                policyDao.getPolicyById(
                        policyNumber);

        if (policy == null) {
            throw new RuntimeException(
                    "Policy not found.");
        }

        policy.setIsActive(Boolean.FALSE);

        Policy updatedPolicy =
                policyDao.updatePolicy(policy);


        // =====================================================
        // NOTIFICATION - POLICY DEACTIVATED
        // =====================================================

        createPolicyNotification(
                updatedPolicy.getPolicyHolder(),
                "Policy Deactivated",
                "Your insurance policy #"
                        + updatedPolicy.getPolicyNumber()
                        + " has been deactivated.",
                "POLICY"
        );


        return policyMapper.convertPolicyEntityToDto(
                updatedPolicy);
    }


    // =========================================================
    // GET POLICIES BY USERNAME
    // =========================================================

    public List<PolicyDto> getPoliciesByUsername(
            String username) {

        if (username == null
                || username.trim().isEmpty()) {

            throw new RuntimeException(
                    "Username is required.");
        }

        User user =
                userDao.getUserByUsername(username);

        if (user == null) {
            throw new RuntimeException(
                    "User not found.");
        }

        return policyDao.getAllPolicies()
                .stream()
                .filter(policy ->
                        policy.getPolicyHolder() != null
                                && policy.getPolicyHolder()
                                        .getUser() != null
                                && policy.getPolicyHolder()
                                        .getUser()
                                        .getUserId()
                                        .equals(
                                                user.getUserId()))
                .map(policyMapper::convertPolicyEntityToDto)
                .collect(Collectors.toList());
    }


    // =========================================================
    // GET AVAILABLE POLICIES
    // =========================================================

    public List<PolicyDto> getAvailablePolicies() {

        return policyDao.getAllPolicies()
                .stream()
                .filter(policy ->
                        Boolean.TRUE.equals(
                                policy.getIsActive()))
                .map(policyMapper::convertPolicyEntityToDto)
                .collect(Collectors.toList());
    }


    // =========================================================
    // CREATE POLICY NOTIFICATION
    // =========================================================

    private void createPolicyNotification(
            PolicyHolder policyHolder,
            String title,
            String message,
            String type) {

        try {

            if (policyHolder == null) {

                System.out.println(
                        "NOTIFICATION SKIPPED: Policy holder is null.");

                return;
            }


            // -------------------------------------------------
            // Get user attached to policy holder
            // -------------------------------------------------

            User user =
                    policyHolder.getUser();


            // -------------------------------------------------
            // If User is not attached, skip notification
            // -------------------------------------------------

            if (user == null) {

                System.out.println(
                        "NOTIFICATION SKIPPED: PolicyHolder has no attached User.");

                return;
            }


            // -------------------------------------------------
            // Validate user ID
            // -------------------------------------------------

            if (user.getUserId() == null) {

                System.out.println(
                        "NOTIFICATION SKIPPED: User ID is null.");

                return;
            }


            System.out.println(
                    "NOTIFICATION: Creating notification for user: "
                            + user.getUsername()
                            + " | userId="
                            + user.getUserId());


            // -------------------------------------------------
            // Save notification
            // -------------------------------------------------

            notificationService.createNotification(
                    user,
                    title,
                    message,
                    type
            );


            System.out.println(
                    "NOTIFICATION: Successfully created -> "
                            + title);

        } catch (Exception e) {

            System.out.println(
                    "NOTIFICATION ERROR: "
                            + e.getClass().getSimpleName()
                            + " - "
                            + e.getMessage());
        }
    }
}