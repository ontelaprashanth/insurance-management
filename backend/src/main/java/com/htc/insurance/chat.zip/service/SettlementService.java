package com.htc.insurance.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.htc.insurance.dto.SettlementDto;
import com.htc.insurance.entity.Claims;
import com.htc.insurance.entity.ClaimStatus;
import com.htc.insurance.entity.Policy;
import com.htc.insurance.entity.PolicyHolder;
import com.htc.insurance.entity.Settlement;
import com.htc.insurance.entity.User;
import com.htc.insurance.repository.ClaimsRepository;
import com.htc.insurance.repository.SettlementRepository;

@Service
public class SettlementService {

    @Autowired
    private SettlementRepository settlementRepository;

    @Autowired
    private ClaimsRepository claimsRepository;

    @Autowired
    private NotificationService notificationService;


    // =========================================================
    // CREATE SETTLEMENT
    // =========================================================

    public SettlementDto saveSettlement(SettlementDto settlementDto) {

        if (settlementDto == null) {
            throw new IllegalArgumentException(
                    "Settlement details are required."
            );
        }

        if (settlementDto.getClaimNumber() == null) {
            throw new IllegalArgumentException(
                    "Claim number is required."
            );
        }

        if (settlementDto.getAmount() == null ||
                settlementDto.getAmount().compareTo(BigDecimal.ZERO) <= 0) {

            throw new IllegalArgumentException(
                    "Settlement amount must be greater than zero."
            );
        }

        if (settlementDto.getSettlementDate() == null) {
            throw new IllegalArgumentException(
                    "Settlement date is required."
            );
        }


        // =====================================================
        // FIND CLAIM
        // =====================================================

        Claims claim = claimsRepository.findById(
                settlementDto.getClaimNumber()
        ).orElseThrow(() ->
                new IllegalArgumentException(
                        "Claim not found: "
                                + settlementDto.getClaimNumber()
                )
        );


        // =====================================================
        // CLAIM MUST BE APPROVED
        // =====================================================

        if (claim.getStatus() != ClaimStatus.APPROVED) {
            throw new IllegalArgumentException(
                    "Settlement can be created only for an approved claim."
            );
        }


        // =====================================================
        // APPROVED AMOUNT MUST EXIST
        // =====================================================

        if (claim.getApprovedAmount() == null) {
            throw new IllegalArgumentException(
                    "Approved amount is not available for this claim."
            );
        }


        // =====================================================
        // SETTLEMENT CANNOT EXCEED APPROVED AMOUNT
        // =====================================================

        if (settlementDto.getAmount().compareTo(
                claim.getApprovedAmount()) > 0) {

            throw new IllegalArgumentException(
                    "Settlement amount cannot exceed the approved claim amount of "
                            + claim.getApprovedAmount()
            );
        }


        // =====================================================
        // ONLY ONE SETTLEMENT PER CLAIM
        // =====================================================

        List<Settlement> existingSettlements =
                settlementRepository.findByClaim_ClaimNumber(
                        settlementDto.getClaimNumber()
                );

        if (!existingSettlements.isEmpty()) {
            throw new IllegalArgumentException(
                    "A settlement already exists for this claim."
            );
        }


        // =====================================================
        // CREATE SETTLEMENT
        // =====================================================

        Settlement settlement = new Settlement();

        settlement.setSettlementDate(
                settlementDto.getSettlementDate()
        );

        settlement.setAmount(
                settlementDto.getAmount()
        );

        // New settlement starts as PENDING
        settlement.setSettlementStatus("PENDING");

        settlement.setClaim(claim);


        Settlement savedSettlement =
                settlementRepository.save(settlement);


        // =====================================================
        // NOTIFICATION - SETTLEMENT CREATED
        // =====================================================

        notifySettlementOwner(
                savedSettlement,
                "Settlement Created",
                "A settlement #"
                        + savedSettlement.getSettlementNumber()
                        + " has been created for your claim #"
                        + claim.getClaimNumber()
                        + " for ₹"
                        + savedSettlement.getAmount()
                        + ". The settlement is currently pending.",
                "SETTLEMENT"
        );


        return mapToDto(savedSettlement);
    }


    // =========================================================
    // PROCESS SETTLEMENT
    // =========================================================

    public SettlementDto processSettlement(Long settlementNumber) {

        if (settlementNumber == null) {
            throw new IllegalArgumentException(
                    "Settlement number is required."
            );
        }


        // =====================================================
        // FIND SETTLEMENT
        // =====================================================

        Settlement settlement =
                settlementRepository.findById(settlementNumber)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Settlement not found: "
                                                + settlementNumber
                                )
                        );


        // =====================================================
        // CLAIM MUST EXIST
        // =====================================================

        if (settlement.getClaim() == null) {
            throw new IllegalArgumentException(
                    "Settlement is not linked to a claim."
            );
        }


        Claims claim = settlement.getClaim();


        // =====================================================
        // CLAIM MUST STILL BE APPROVED
        // =====================================================

        if (claim.getStatus() != ClaimStatus.APPROVED) {
            throw new IllegalArgumentException(
                    "Only settlements for approved claims can be processed."
            );
        }


        // =====================================================
        // ONLY PENDING SETTLEMENT CAN BE PROCESSED
        // =====================================================

        if (!"PENDING".equalsIgnoreCase(
                settlement.getSettlementStatus())) {

            throw new IllegalArgumentException(
                    "Only pending settlements can be processed."
            );
        }


        // =====================================================
        // APPROVED AMOUNT SAFETY CHECK
        // =====================================================

        if (claim.getApprovedAmount() == null) {
            throw new IllegalArgumentException(
                    "Approved claim amount is not available."
            );
        }


        // =====================================================
        // FINAL AMOUNT VALIDATION
        // =====================================================

        if (settlement.getAmount().compareTo(
                claim.getApprovedAmount()) > 0) {

            throw new IllegalArgumentException(
                    "Settlement amount cannot exceed the approved claim amount."
            );
        }


        // =====================================================
        // COMPLETE SETTLEMENT
        // =====================================================

        settlement.setSettlementStatus("SETTLED");

        Settlement updatedSettlement =
                settlementRepository.save(settlement);


        // =====================================================
        // NOTIFICATION - SETTLEMENT COMPLETED
        // =====================================================

        notifySettlementOwner(
                updatedSettlement,
                "Settlement Completed",
                "Your settlement #"
                        + updatedSettlement.getSettlementNumber()
                        + " for claim #"
                        + claim.getClaimNumber()
                        + " has been successfully settled for ₹"
                        + updatedSettlement.getAmount()
                        + ".",
                "SETTLEMENT"
        );


        return mapToDto(updatedSettlement);
    }


    // =========================================================
    // GET ALL SETTLEMENTS
    // =========================================================

    public List<SettlementDto> getAllSettlements() {

        return settlementRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }


    // =========================================================
    // GET SETTLEMENT BY ID
    // =========================================================

    public SettlementDto getSettlementById(Long settlementNumber) {

        Settlement settlement =
                settlementRepository.findById(settlementNumber)
                        .orElse(null);

        if (settlement == null) {
            return null;
        }

        return mapToDto(settlement);
    }


    // =========================================================
    // GET SETTLEMENTS BY CLAIM
    // =========================================================

    public List<SettlementDto> getSettlementsByClaimNumber(
            Long claimNumber) {

        return settlementRepository
                .findByClaim_ClaimNumber(claimNumber)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }


    // =========================================================
    // UPDATE SETTLEMENT
    // =========================================================

    public SettlementDto updateSettlement(
            Long settlementNumber,
            SettlementDto settlementDto) {

        if (settlementNumber == null) {
            throw new IllegalArgumentException(
                    "Settlement number is required."
            );
        }

        if (settlementDto == null) {
            throw new IllegalArgumentException(
                    "Settlement details are required."
            );
        }


        // =====================================================
        // FIND EXISTING SETTLEMENT
        // =====================================================

        Settlement settlement =
                settlementRepository.findById(settlementNumber)
                        .orElse(null);

        if (settlement == null) {
            return null;
        }


        // =====================================================
        // ONLY PENDING SETTLEMENT CAN BE UPDATED
        // =====================================================

        if (!"PENDING".equalsIgnoreCase(
                settlement.getSettlementStatus())) {

            throw new IllegalArgumentException(
                    "Only pending settlements can be updated."
            );
        }


        // =====================================================
        // VALIDATE AMOUNT
        // =====================================================

        if (settlementDto.getAmount() == null ||
                settlementDto.getAmount().compareTo(BigDecimal.ZERO) <= 0) {

            throw new IllegalArgumentException(
                    "Settlement amount must be greater than zero."
            );
        }


        // =====================================================
        // VALIDATE DATE
        // =====================================================

        if (settlementDto.getSettlementDate() == null) {
            throw new IllegalArgumentException(
                    "Settlement date is required."
            );
        }


        // =====================================================
        // CLAIM
        // =====================================================

        Claims claim = settlement.getClaim();

        if (claim == null) {
            throw new IllegalArgumentException(
                    "Settlement is not linked to a claim."
            );
        }


        // =====================================================
        // CLAIM MUST BE APPROVED
        // =====================================================

        if (claim.getStatus() != ClaimStatus.APPROVED) {
            throw new IllegalArgumentException(
                    "Settlement can be updated only for an approved claim."
            );
        }


        // =====================================================
        // APPROVED AMOUNT
        // =====================================================

        if (claim.getApprovedAmount() == null) {
            throw new IllegalArgumentException(
                    "Approved claim amount is not available."
            );
        }


        // =====================================================
        // AMOUNT LIMIT
        // =====================================================

        if (settlementDto.getAmount().compareTo(
                claim.getApprovedAmount()) > 0) {

            throw new IllegalArgumentException(
                    "Settlement amount cannot exceed the approved claim amount of "
                            + claim.getApprovedAmount()
            );
        }


        // =====================================================
        // UPDATE
        // =====================================================

        settlement.setSettlementDate(
                settlementDto.getSettlementDate()
        );

        settlement.setAmount(
                settlementDto.getAmount()
        );

        // Status remains PENDING.
        // Only processSettlement() can change it to SETTLED.


        Settlement updatedSettlement =
                settlementRepository.save(settlement);


        // =====================================================
        // NOTIFICATION - SETTLEMENT UPDATED
        // =====================================================

        notifySettlementOwner(
                updatedSettlement,
                "Settlement Updated",
                "Your settlement #"
                        + updatedSettlement.getSettlementNumber()
                        + " for claim #"
                        + claim.getClaimNumber()
                        + " has been updated. "
                        + "Current settlement amount is ₹"
                        + updatedSettlement.getAmount()
                        + ".",
                "SETTLEMENT"
        );


        return mapToDto(updatedSettlement);
    }


    // =========================================================
    // DELETE SETTLEMENT
    // =========================================================

    public void deleteSettlement(Long settlementNumber) {

        if (settlementNumber == null) {
            throw new IllegalArgumentException(
                    "Settlement number is required."
            );
        }


        // =====================================================
        // FIND SETTLEMENT BEFORE DELETE
        // =====================================================

        Settlement settlement =
                settlementRepository.findById(
                        settlementNumber)
                        .orElse(null);

        if (settlement == null) {
            throw new IllegalArgumentException(
                    "Settlement not found: "
                            + settlementNumber
            );
        }


        // =====================================================
        // ONLY PENDING SETTLEMENT CAN BE DELETED
        // =====================================================

        if (!"PENDING".equalsIgnoreCase(
                settlement.getSettlementStatus())) {

            throw new IllegalArgumentException(
                    "Only pending settlements can be deleted."
            );
        }


        // =====================================================
        // DELETE
        // =====================================================

        settlementRepository.delete(
                settlement);


        // =====================================================
        // NOTIFICATION - SETTLEMENT DELETED
        // =====================================================

        notifySettlementOwner(
                settlement,
                "Settlement Deleted",
                "Your settlement #"
                        + settlementNumber
                        + " for claim #"
                        + getClaimNumber(settlement)
                        + " has been deleted.",
                "SETTLEMENT"
        );
    }


    // =========================================================
    // NOTIFY SETTLEMENT OWNER
    // =========================================================

    private void notifySettlementOwner(
            Settlement settlement,
            String title,
            String message,
            String type) {

        if (settlement == null) {
            System.out.println(
                    "NOTIFICATION SKIPPED: Settlement is null.");
            return;
        }

        Claims claim =
                settlement.getClaim();

        if (claim == null) {
            System.out.println(
                    "NOTIFICATION SKIPPED: Settlement has no claim.");
            return;
        }

        Policy policy =
                claim.getPolicy();

        if (policy == null) {
            System.out.println(
                    "NOTIFICATION SKIPPED: Claim has no policy.");
            return;
        }

        PolicyHolder policyHolder =
                policy.getPolicyHolder();

        if (policyHolder == null) {
            System.out.println(
                    "NOTIFICATION SKIPPED: Policy holder is null.");
            return;
        }

        User customer =
                policyHolder.getUser();

        if (customer == null) {
            System.out.println(
                    "NOTIFICATION SKIPPED: Policy holder has no user.");
            return;
        }

        if (customer.getUserId() == null) {
            System.out.println(
                    "NOTIFICATION SKIPPED: Customer user ID is null.");
            return;
        }


        try {

            System.out.println(
                    "NOTIFICATION: Creating settlement notification "
                            + "for user: "
                            + customer.getUsername()
                            + " | userId="
                            + customer.getUserId());


            notificationService.createNotification(
                    customer,
                    title,
                    message,
                    type
            );


            System.out.println(
                    "NOTIFICATION: Successfully created -> "
                            + title);

        } catch (Exception e) {

            System.out.println(
                    "NOTIFICATION ERROR: "
                            + e.getClass().getSimpleName()
                            + " - "
                            + e.getMessage());
        }
    }


    // =========================================================
    // GET CLAIM NUMBER
    // =========================================================

    private Long getClaimNumber(
            Settlement settlement) {

        if (settlement == null ||
                settlement.getClaim() == null) {

            return null;
        }

        return settlement.getClaim()
                .getClaimNumber();
    }


    // =========================================================
    // ENTITY → DTO
    // =========================================================

    private SettlementDto mapToDto(
            Settlement settlement) {

        SettlementDto dto =
                new SettlementDto();

        dto.setSettlementNumber(
                settlement.getSettlementNumber()
        );

        dto.setSettlementDate(
                settlement.getSettlementDate()
        );

        dto.setAmount(
                settlement.getAmount()
        );

        dto.setSettlementStatus(
                settlement.getSettlementStatus()
        );

        if (settlement.getClaim() != null) {

            dto.setClaimNumber(
                    settlement.getClaim()
                            .getClaimNumber()
            );
        }

        return dto;
    }
}