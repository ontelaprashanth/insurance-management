package com.htc.insurance.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.htc.insurance.dao.ClaimsDao;
import com.htc.insurance.dao.SettlementDao;
import com.htc.insurance.dto.SettlementDto;
import com.htc.insurance.entity.ClaimStatus;
import com.htc.insurance.entity.Claims;
import com.htc.insurance.entity.Settlement;

@Service
public class SettlementService {

    @Autowired
    private SettlementDao settlementDao;

    @Autowired
    private ClaimsDao claimsDao;


    /* =====================================================
       SAVE SETTLEMENT
    ===================================================== */

    public SettlementDto saveSettlement(
            SettlementDto settlementDto) {

        if (settlementDto == null) {
            throw new IllegalArgumentException(
                    "Settlement data is required."
            );
        }


        if (settlementDto.getClaimNumber() == null) {
            throw new IllegalArgumentException(
                    "Claim number is required."
            );
        }


        if (settlementDto.getAmount() == null ||
                settlementDto.getAmount()
                        .compareTo(BigDecimal.ZERO) <= 0) {

            throw new IllegalArgumentException(
                    "Settlement amount must be greater than zero."
            );
        }


        if (settlementDto.getSettlementDate() == null) {
            throw new IllegalArgumentException(
                    "Settlement date is required."
            );
        }


        /*
         * Find claim
         */

        Claims claim =
                claimsDao.getClaimsById(
                        settlementDto.getClaimNumber()
                );


        if (claim == null) {

            throw new IllegalArgumentException(
                    "Claim not found."
            );

        }


        /*
         * Settlement is allowed only for
         * APPROVED claims.
         */

        if (claim.getStatus() != ClaimStatus.APPROVED) {

            throw new IllegalArgumentException(
                    "Only approved claims can be settled."
            );

        }


        /*
         * Settlement amount cannot exceed
         * approved claim amount.
         */

        if (claim.getAmount() == null) {

            throw new IllegalArgumentException(
                    "Claim amount is not available."
            );

        }


        if (
            settlementDto
                .getAmount()
                .compareTo(
                    claim.getAmount()
                ) > 0
        ) {

            throw new IllegalArgumentException(
                    "Settlement amount cannot be greater than the approved claim amount."
            );

        }


        /*
         * Check whether the claim has already
         * been settled.
         */

        List<Settlement> existingSettlements =
                settlementDao
                    .getSettlementsByClaimNumber(
                        settlementDto.getClaimNumber()
                    );


        boolean alreadySettled =
                existingSettlements
                    .stream()
                    .anyMatch(
                        settlement ->
                            "SETTLED".equalsIgnoreCase(
                                settlement
                                    .getSettlementStatus()
                            )
                    );


        if (alreadySettled) {

            throw new IllegalArgumentException(
                    "This claim has already been settled."
            );

        }


        /*
         * Create settlement
         */

        Settlement settlement =
                new Settlement();


        settlement.setSettlementDate(
                settlementDto.getSettlementDate()
        );


        settlement.setAmount(
                settlementDto.getAmount()
        );


        /*
         * Status is controlled by backend.
         */

        settlement.setSettlementStatus(
                "SETTLED"
        );


        settlement.setClaim(
                claim
        );


        Settlement savedSettlement =
                settlementDao.saveSettlement(
                        settlement
                );


        return convertToDto(
                savedSettlement
        );
    }


    /* =====================================================
       GET ALL SETTLEMENTS
    ===================================================== */

    public List<SettlementDto> getAllSettlements() {

        return settlementDao
                .getAllSettlements()
                .stream()
                .map(
                    this::convertToDto
                )
                .collect(
                    Collectors.toList()
                );
    }


    /* =====================================================
       GET SETTLEMENT BY ID
    ===================================================== */

    public SettlementDto getSettlementById(
            Long settlementNumber) {

        Settlement settlement =
                settlementDao.getSettlementById(
                        settlementNumber
                );


        if (settlement == null) {
            return null;
        }


        return convertToDto(
                settlement
        );
    }


    /* =====================================================
       GET SETTLEMENTS BY CLAIM
    ===================================================== */

    public List<SettlementDto> getSettlementsByClaimNumber(
            Long claimNumber) {

        return settlementDao
                .getSettlementsByClaimNumber(
                        claimNumber
                )
                .stream()
                .map(
                    this::convertToDto
                )
                .collect(
                    Collectors.toList()
                );
    }


    /* =====================================================
       UPDATE SETTLEMENT
    ===================================================== */

    public SettlementDto updateSettlement(
            Long settlementNumber,
            SettlementDto settlementDto) {

        Settlement existing =
                settlementDao.getSettlementById(
                        settlementNumber
                );


        if (existing == null) {
            return null;
        }


        if (settlementDto.getAmount() == null ||
                settlementDto.getAmount()
                        .compareTo(BigDecimal.ZERO) <= 0) {

            throw new IllegalArgumentException(
                    "Settlement amount must be greater than zero."
            );

        }


        if (settlementDto.getSettlementDate() == null) {

            throw new IllegalArgumentException(
                    "Settlement date is required."
            );

        }


        Claims claim =
                existing.getClaim();


        if (claim == null) {

            throw new IllegalArgumentException(
                    "Claim associated with settlement not found."
            );

        }


        if (settlementDto
                .getAmount()
                .compareTo(
                    claim.getAmount()
                ) > 0) {

            throw new IllegalArgumentException(
                    "Settlement amount cannot be greater than the approved claim amount."
            );

        }


        existing.setSettlementDate(
                settlementDto.getSettlementDate()
        );


        existing.setAmount(
                settlementDto.getAmount()
        );


        /*
         * Do not allow frontend to change
         * settlement status arbitrarily.
         */

        existing.setSettlementStatus(
                "SETTLED"
        );


        Settlement updated =
                settlementDao.updateSettlement(
                        existing
                );


        return convertToDto(
                updated
        );
    }


    /* =====================================================
       DELETE SETTLEMENT
    ===================================================== */

    public void deleteSettlement(
            Long settlementNumber) {

        Settlement settlement =
                settlementDao.getSettlementById(
                        settlementNumber
                );


        if (settlement == null) {

            throw new IllegalArgumentException(
                    "Settlement not found."
            );

        }


        settlementDao.deleteSettlement(
                settlementNumber
        );
    }


    /* =====================================================
       ENTITY → DTO
    ===================================================== */

    private SettlementDto convertToDto(
            Settlement settlement) {

        SettlementDto dto =
                new SettlementDto();


        dto.setSettlementNumber(
                settlement.getSettlementNumber()
        );


        dto.setSettlementDate(
                settlement.getSettlementDate()
        );


        dto.setAmount(
                settlement.getAmount()
        );


        dto.setSettlementStatus(
                settlement.getSettlementStatus()
        );


        if (settlement.getClaim() != null) {

            dto.setClaimNumber(
                    settlement
                        .getClaim()
                        .getClaimNumber()
            );

        }


        return dto;
    }
}