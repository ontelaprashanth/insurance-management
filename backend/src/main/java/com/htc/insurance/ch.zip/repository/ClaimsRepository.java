package com.htc.insurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.htc.insurance.entity.Claims;

public interface ClaimsRepository
        extends JpaRepository<Claims, Long> {
}