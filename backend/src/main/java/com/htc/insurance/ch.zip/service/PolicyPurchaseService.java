package com.htc.insurance.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.htc.insurance.dao.PolicyDao;
import com.htc.insurance.dao.PolicyHolderDao;
import com.htc.insurance.dao.PolicyPurchaseDao;
import com.htc.insurance.dao.UserDao;
import com.htc.insurance.dto.PurchasePolicyDto;
import com.htc.insurance.entity.Policy;
import com.htc.insurance.entity.PolicyHolder;
import com.htc.insurance.entity.PolicyPurchase;
import com.htc.insurance.entity.User;

@Service
public class PolicyPurchaseService {

    @Autowired
    private PolicyDao policyDao;

    @Autowired
    private PolicyHolderDao policyHolderDao;

    @Autowired
    private UserDao userDao;

    @Autowired
    private PolicyPurchaseDao policyPurchaseDao;


    // =========================================================
    // PURCHASE POLICY
    // =========================================================

    @Transactional
    public PurchasePolicyDto purchasePolicy(
            PurchasePolicyDto purchaseDto,
            Authentication authentication) {

        // -----------------------------------------------------
        // AUTHENTICATION
        // -----------------------------------------------------

        if (authentication == null ||
                authentication.getName() == null) {

            throw new RuntimeException(
                    "User authentication is required."
            );
        }


        // -----------------------------------------------------
        // REQUEST VALIDATION
        // -----------------------------------------------------

        if (purchaseDto == null) {

            throw new RuntimeException(
                    "Purchase details are required."
            );
        }


        if (purchaseDto.getCoveredTypes() == null ||
                purchaseDto.getCoveredTypes().isBlank()) {

            throw new RuntimeException(
                    "Insurance plan is required."
            );
        }


        if (purchaseDto.getDurationYears() == null ||
                purchaseDto.getDurationYears() <= 0) {

            throw new RuntimeException(
                    "Valid policy duration is required."
            );
        }


        if (purchaseDto.getDurationYears() > 5) {

            throw new RuntimeException(
                    "Maximum policy duration is 5 years."
            );
        }


        if (purchaseDto.getCoverageAmount() == null ||
                purchaseDto.getCoverageAmount()
                        .compareTo(BigDecimal.ZERO) <= 0) {

            throw new RuntimeException(
                    "Valid coverage amount is required."
            );
        }


        // -----------------------------------------------------
        // COVERAGE VALIDATION
        // -----------------------------------------------------

        BigDecimal minimumCoverage =
                BigDecimal.valueOf(1_000_000);

        BigDecimal maximumCoverage =
                BigDecimal.valueOf(10_000_000);


        if (purchaseDto.getCoverageAmount()
                .compareTo(minimumCoverage) < 0) {

            throw new RuntimeException(
                    "Minimum coverage amount is ₹10,00,000."
            );
        }


        if (purchaseDto.getCoverageAmount()
                .compareTo(maximumCoverage) > 0) {

            throw new RuntimeException(
                    "Maximum coverage amount is ₹1,00,00,000."
            );
        }


        // -----------------------------------------------------
        // NOMINEE VALIDATION
        // -----------------------------------------------------

        if (purchaseDto.getNomineeName() == null ||
                purchaseDto.getNomineeName().isBlank()) {

            throw new RuntimeException(
                    "Nominee name is required."
            );
        }


        if (purchaseDto.getNomineeRelation() == null ||
                purchaseDto.getNomineeRelation().isBlank()) {

            throw new RuntimeException(
                    "Nominee relationship is required."
            );
        }


        if (purchaseDto.getNomineeContact() == null ||
                purchaseDto.getNomineeContact().isBlank()) {

            throw new RuntimeException(
                    "Nominee contact is required."
            );
        }


        // -----------------------------------------------------
        // PAYMENT METHOD
        // -----------------------------------------------------

        if (purchaseDto.getPaymentMethod() == null ||
                purchaseDto.getPaymentMethod().isBlank()) {

            throw new RuntimeException(
                    "Payment method is required."
            );
        }


        // -----------------------------------------------------
        // RAZORPAY VALIDATION
        // -----------------------------------------------------

        if (purchaseDto.getRazorpayOrderId() == null ||
                purchaseDto.getRazorpayOrderId().isBlank()) {

            throw new RuntimeException(
                    "Razorpay order ID is required."
            );
        }


        if (purchaseDto.getRazorpayPaymentId() == null ||
                purchaseDto.getRazorpayPaymentId().isBlank()) {

            throw new RuntimeException(
                    "Razorpay payment ID is required."
            );
        }


        // =====================================================
        // GET LOGGED-IN USER
        // =====================================================

        String username =
                authentication.getName();


        User user =
                userDao.getUserByUsername(username);


        if (user == null) {

            throw new RuntimeException(
                    "Logged-in user not found."
            );
        }


        // =====================================================
        // GET POLICY HOLDER
        // =====================================================

        PolicyHolder policyHolder =
                policyHolderDao
                        .getPolicyHolderByUsername(username);


        if (policyHolder == null) {

            throw new RuntimeException(
                    "Policy holder profile not found. "
                    + "Please contact the administrator."
            );
        }


        // =====================================================
        // CALCULATE PREMIUM
        // =====================================================

        BigDecimal basePremium =
                calculateBasePremium(
                        purchaseDto.getCoveredTypes(),
                        purchaseDto.getDurationYears(),
                        purchaseDto.getCoverageAmount()
                );


        // -----------------------------------------------------
        // DISCOUNT
        // -----------------------------------------------------

        BigDecimal discountAmount =
                calculateDiscount(
                        basePremium,
                        purchaseDto.getDurationYears()
                );


        // -----------------------------------------------------
        // TAXABLE AMOUNT
        // -----------------------------------------------------

        BigDecimal taxableAmount =
                basePremium
                        .subtract(discountAmount)
                        .setScale(
                                2,
                                RoundingMode.HALF_UP
                        );


        // -----------------------------------------------------
        // GST
        // -----------------------------------------------------

        BigDecimal gstRate =
                BigDecimal.ZERO;


        BigDecimal gstAmount =
                taxableAmount
                        .multiply(gstRate)
                        .divide(
                                BigDecimal.valueOf(100),
                                2,
                                RoundingMode.HALF_UP
                        );


        // -----------------------------------------------------
        // TOTAL PREMIUM
        // -----------------------------------------------------

        BigDecimal totalPremium =
                taxableAmount
                        .add(gstAmount)
                        .setScale(
                                2,
                                RoundingMode.HALF_UP
                        );


        // =====================================================
        // POLICY DATES
        // =====================================================

        /*
         * Policy starts on the purchase date.
         *
         * Expiry date is calculated from the selected
         * duration.
         *
         * Example:
         *
         * 1 year:
         * 29-09-2026 -> 28-09-2027
         *
         * 2 years:
         * 29-09-2026 -> 28-09-2028
         *
         * 3 years:
         * 29-09-2026 -> 28-09-2029
         *
         * 5 years:
         * 29-09-2026 -> 28-09-2031
         */

        LocalDate startDate =
                LocalDate.now();


        LocalDate expiryDate =
                startDate
                        .plusYears(
                                purchaseDto.getDurationYears()
                        )
                        .minusDays(1);


        // =====================================================
        // CREATE POLICY
        // =====================================================

        Policy policy =
                new Policy();


        policy.setCoveredTypes(
                purchaseDto.getCoveredTypes()
        );


        policy.setIsActive(
                true
        );


        // IMPORTANT
        policy.setStartDate(
                startDate
        );


        policy.setDurationYears(
                purchaseDto.getDurationYears()
        );


        // IMPORTANT
        policy.setExpiryDate(
                expiryDate
        );


        policy.setPolicyHolder(
                policyHolder
        );


        Policy savedPolicy =
                policyDao.savePolicy(
                        policy
                );


        // =====================================================
        // CREATE PURCHASE
        // =====================================================

        PolicyPurchase purchase =
                new PolicyPurchase();


        purchase.setPolicy(
                savedPolicy
        );


        // -----------------------------------------------------
        // COVERAGE
        // -----------------------------------------------------

        purchase.setCoverageAmount(
                purchaseDto.getCoverageAmount()
                        .setScale(
                                2,
                                RoundingMode.HALF_UP
                        )
        );


        // -----------------------------------------------------
        // PREMIUM
        // -----------------------------------------------------

        purchase.setBasePremium(
                basePremium
        );


        purchase.setDiscountAmount(
                discountAmount
        );


        purchase.setTaxableAmount(
                taxableAmount
        );


        purchase.setGstRate(
                gstRate
        );


        purchase.setGstAmount(
                gstAmount
        );


        purchase.setTotalPremium(
                totalPremium
        );


        // -----------------------------------------------------
        // NOMINEE
        // -----------------------------------------------------

        purchase.setNomineeName(
                purchaseDto.getNomineeName()
        );


        purchase.setNomineeRelation(
                purchaseDto.getNomineeRelation()
        );


        purchase.setNomineeContact(
                purchaseDto.getNomineeContact()
        );


        // -----------------------------------------------------
        // PAYMENT METHOD
        // -----------------------------------------------------

        purchase.setPaymentMethod(
                purchaseDto.getPaymentMethod()
        );


        // -----------------------------------------------------
        // PAYMENT STATUS
        // -----------------------------------------------------

        purchase.setPaymentStatus(
                "PAID"
        );


        // -----------------------------------------------------
        // RAZORPAY ORDER ID
        // -----------------------------------------------------

        purchase.setRazorpayOrderId(
                purchaseDto.getRazorpayOrderId()
        );


        // -----------------------------------------------------
        // RAZORPAY PAYMENT ID
        // -----------------------------------------------------

        purchase.setRazorpayPaymentId(
                purchaseDto.getRazorpayPaymentId()
        );


        // -----------------------------------------------------
        // TRANSACTION ID
        // -----------------------------------------------------

        purchase.setTransactionId(
                purchaseDto.getRazorpayPaymentId()
        );


        // -----------------------------------------------------
        // PAYMENT DATE
        // -----------------------------------------------------

        LocalDateTime paymentDateTime =
                LocalDateTime.now();


        purchase.setPaymentDateTime(
                paymentDateTime
        );


        purchase.setPaymentDate(
                paymentDateTime.toLocalDate()
        );


        // -----------------------------------------------------
        // PURCHASE DATE
        // -----------------------------------------------------

        purchase.setPurchaseDate(
                startDate
        );


        // -----------------------------------------------------
        // CREATED DATE
        // -----------------------------------------------------

        purchase.setCreatedAt(
                LocalDateTime.now()
        );


        // -----------------------------------------------------
        // REFUND DEFAULT VALUES
        // -----------------------------------------------------

        purchase.setRefundStatus(
                "NOT_REFUNDED"
        );


        purchase.setRefundAmount(
                BigDecimal.ZERO
        );


        // =====================================================
        // SAVE PURCHASE
        // =====================================================

        PolicyPurchase savedPurchase =
                policyPurchaseDao.savePurchase(
                        purchase
                );


        // =====================================================
        // RETURN RESPONSE
        // =====================================================

        return buildPurchaseResponse(
                savedPurchase
        );
    }


    // =========================================================
    // GET ALL PURCHASES
    // =========================================================

    @Transactional(readOnly = true)
    public List<PurchasePolicyDto> getAllPurchases() {

        List<PolicyPurchase> purchases =
                policyPurchaseDao.getAllPurchases();


        return purchases.stream()
                .map(this::buildPurchaseResponse)
                .toList();
    }


    // =========================================================
    // GET CURRENT USER PURCHASES
    // =========================================================

    @Transactional(readOnly = true)
    public List<PurchasePolicyDto> getMyPurchases(
            Authentication authentication) {

        if (authentication == null ||
                authentication.getName() == null) {

            throw new RuntimeException(
                    "User authentication is required."
            );
        }


        String username =
                authentication.getName();


        List<PolicyPurchase> purchases =
                policyPurchaseDao
                        .getPurchasesByUsername(username);


        return purchases.stream()
                .map(this::buildPurchaseResponse)
                .toList();
    }


    // =========================================================
    // BUILD PURCHASE RESPONSE
    // =========================================================

    private PurchasePolicyDto buildPurchaseResponse(
            PolicyPurchase purchase) {

        PurchasePolicyDto response =
                new PurchasePolicyDto();


        // -----------------------------------------------------
        // PURCHASE ID
        // -----------------------------------------------------

        response.setPurchaseId(
                purchase.getPurchaseId()
        );


        // =====================================================
        // POLICY INFORMATION
        // =====================================================

        if (purchase.getPolicy() != null) {

            Policy policy =
                    purchase.getPolicy();


            response.setPolicyNumber(
                    policy.getPolicyNumber()
            );


            response.setCoveredTypes(
                    policy.getCoveredTypes()
            );


            response.setDurationYears(
                    policy.getDurationYears()
            );


            // IMPORTANT:
            // Return actual policy start date
            response.setStartDate(
                    policy.getStartDate()
            );


            // IMPORTANT:
            // Return actual policy expiry date
            response.setExpiryDate(
                    policy.getExpiryDate()
            );


            // -------------------------------------------------
            // USERNAME
            // -------------------------------------------------

            if (policy.getPolicyHolder() != null
                    && policy.getPolicyHolder()
                            .getUser() != null) {

                response.setUsername(
                        policy.getPolicyHolder()
                                .getUser()
                                .getUsername()
                );
            }
        }


        // =====================================================
        // COVERAGE
        // =====================================================

        response.setCoverageAmount(
                purchase.getCoverageAmount()
        );


        // =====================================================
        // PREMIUM
        // =====================================================

        response.setBasePremium(
                purchase.getBasePremium()
        );


        response.setDiscountAmount(
                purchase.getDiscountAmount()
        );


        response.setTaxableAmount(
                purchase.getTaxableAmount()
        );


        response.setGstRate(
                purchase.getGstRate()
        );


        response.setGstAmount(
                purchase.getGstAmount()
        );


        response.setTotalPremium(
                purchase.getTotalPremium()
        );


        // =====================================================
        // NOMINEE
        // =====================================================

        response.setNomineeName(
                purchase.getNomineeName()
        );


        response.setNomineeRelation(
                purchase.getNomineeRelation()
        );


        response.setNomineeContact(
                purchase.getNomineeContact()
        );


        // =====================================================
        // PAYMENT DETAILS
        // =====================================================

        response.setPaymentMethod(
                purchase.getPaymentMethod()
        );


        response.setPaymentStatus(
                purchase.getPaymentStatus()
        );


        response.setTransactionId(
                purchase.getTransactionId()
        );


        response.setRazorpayOrderId(
                purchase.getRazorpayOrderId()
        );


        response.setRazorpayPaymentId(
                purchase.getRazorpayPaymentId()
        );


        response.setPaymentDate(
                purchase.getPaymentDate()
        );


        response.setPaymentDateTime(
                purchase.getPaymentDateTime()
        );


        // =====================================================
        // PURCHASE DETAILS
        // =====================================================

        response.setPurchaseDate(
                purchase.getPurchaseDate()
        );


        response.setCreatedAt(
                purchase.getCreatedAt()
        );


        // =====================================================
        // REFUND DETAILS
        // =====================================================

        response.setRefundStatus(
                purchase.getRefundStatus()
        );


        response.setRefundId(
                purchase.getRefundId()
        );


        response.setRefundAmount(
                purchase.getRefundAmount()
        );


        response.setRefundReason(
                purchase.getRefundReason()
        );


        response.setRefundDateTime(
                purchase.getRefundDateTime()
        );


        // =====================================================
        // REFUND ELIGIBILITY
        // =====================================================

        LocalDateTime paymentTime =
                purchase.getPaymentDateTime();


        if (paymentTime != null) {

            LocalDateTime refundDeadline =
                    paymentTime.plusHours(24);


            response.setRefundDeadline(
                    refundDeadline
            );


            boolean alreadyRefunded =
                    "REFUNDED".equalsIgnoreCase(
                            purchase.getRefundStatus()
                    );


            boolean eligible =
                    !alreadyRefunded
                    && LocalDateTime.now()
                            .isBefore(
                                    refundDeadline
                            );


            response.setRefundEligible(
                    eligible
            );

        } else {

            response.setRefundDeadline(
                    null
            );


            response.setRefundEligible(
                    false
            );
        }


        return response;
    }


    // =========================================================
    // CALCULATE BASE PREMIUM
    // =========================================================

    private BigDecimal calculateBasePremium(
            String coveredTypes,
            Integer durationYears,
            BigDecimal coverageAmount) {

        BigDecimal yearlyBasePremium;


        String plan =
                coveredTypes
                        .trim()
                        .toLowerCase();


        // -----------------------------------------------------
        // BASE PREMIUM
        // -----------------------------------------------------

        if (plan.contains("health")) {

            yearlyBasePremium =
                    BigDecimal.valueOf(8999);

        } else if (plan.contains("motor")) {

            yearlyBasePremium =
                    BigDecimal.valueOf(2499);

        } else if (plan.contains("life")) {

            yearlyBasePremium =
                    BigDecimal.valueOf(6999);

        } else if (plan.contains("travel")) {

            yearlyBasePremium =
                    BigDecimal.valueOf(799);

        } else if (plan.contains("home")) {

            yearlyBasePremium =
                    BigDecimal.valueOf(2999);

        } else if (plan.contains("accident")) {

            yearlyBasePremium =
                    BigDecimal.valueOf(1499);

        } else {

            throw new RuntimeException(
                    "Unsupported insurance plan: "
                            + coveredTypes
            );
        }


        // -----------------------------------------------------
        // MINIMUM COVERAGE
        // -----------------------------------------------------

        BigDecimal minimumCoverage =
                BigDecimal.valueOf(1_000_000);


        // -----------------------------------------------------
        // COVERAGE MULTIPLIER
        // -----------------------------------------------------

        BigDecimal coverageMultiplier =
                coverageAmount.divide(
                        minimumCoverage,
                        4,
                        RoundingMode.HALF_UP
                );


        // -----------------------------------------------------
        // YEARLY PREMIUM
        // -----------------------------------------------------

        BigDecimal coverageBasedYearlyPremium =
                yearlyBasePremium
                        .multiply(
                                coverageMultiplier
                        );


        // -----------------------------------------------------
        // TOTAL BASE PREMIUM
        // -----------------------------------------------------

        BigDecimal totalBasePremium =
                coverageBasedYearlyPremium
                        .multiply(
                                BigDecimal.valueOf(
                                        durationYears
                                )
                        );


        return totalBasePremium.setScale(
                2,
                RoundingMode.HALF_UP
        );
    }


    // =========================================================
    // CALCULATE DISCOUNT
    // =========================================================

    private BigDecimal calculateDiscount(
            BigDecimal basePremium,
            Integer durationYears) {

        // 5% discount for 2 years or more
        if (durationYears >= 2) {

            return basePremium
                    .multiply(
                            BigDecimal.valueOf(5)
                    )
                    .divide(
                            BigDecimal.valueOf(100),
                            2,
                            RoundingMode.HALF_UP
                    );
        }


        return BigDecimal.ZERO.setScale(
                2,
                RoundingMode.HALF_UP
        );
    }
}