package com.htc.insurance.service;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.htc.insurance.dto.LoginRequest;
import com.htc.insurance.dto.LoginResponse;
import com.htc.insurance.security.JwtService;

@Service
public class AuthService {

    private final AuthenticationManager authenticationManager;

    private final JwtService jwtService;

    public AuthService(
            AuthenticationManager authenticationManager,
            JwtService jwtService) {

        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    public LoginResponse login(LoginRequest loginRequest) {

        // Authenticate username and password
        Authentication authentication =
                authenticationManager.authenticate(
                        new UsernamePasswordAuthenticationToken(
                                loginRequest.getUsername(),
                                loginRequest.getPassword()
                        )
                );

        // Get username
        String username =
                authentication.getName();

        // Get role
        String role =
                authentication.getAuthorities()
                        .stream()
                        .findFirst()
                        .map(authority ->
                                authority.getAuthority())
                        .orElse("ROLE_USER");

        // Remove ROLE_ prefix
        role = role.replace("ROLE_", "");

        // Generate JWT with username + role
        String token =
                jwtService.generateToken(
                        username,
                        role
                );

        return new LoginResponse(token);
    }
}