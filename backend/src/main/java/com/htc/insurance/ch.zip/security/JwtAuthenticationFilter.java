package com.htc.insurance.security;

import java.io.IOException;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter
        extends OncePerRequestFilter {


    private final JwtService jwtService;

    private final UserDetailsService userDetailsService;


    public JwtAuthenticationFilter(
            JwtService jwtService,
            UserDetailsService userDetailsService) {

        this.jwtService =
                jwtService;

        this.userDetailsService =
                userDetailsService;
    }


    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {


        String path =
                request.getServletPath();


        System.out.println(
                "================================="
        );

        System.out.println(
                "JWT FILTER REQUEST: "
                        + path
        );


        // =====================================================
        // OPTIONS
        // =====================================================

        if ("OPTIONS".equalsIgnoreCase(
                request.getMethod())) {

            System.out.println(
                    "OPTIONS REQUEST - SKIPPING JWT"
            );

            filterChain.doFilter(
                    request,
                    response
            );

            return;
        }


        // =====================================================
        // LOGIN
        // =====================================================

        if (path.equals(
                "/api/auth/login")) {

            System.out.println(
                    "LOGIN REQUEST - SKIPPING JWT"
            );

            filterChain.doFilter(
                    request,
                    response
            );

            return;
        }


        // =====================================================
        // AUTHORIZATION HEADER
        // =====================================================

        String authHeader =
                request.getHeader(
                        "Authorization"
                );


        System.out.println(
                "AUTHORIZATION HEADER PRESENT: "
                        + (authHeader != null)
        );


        /*
         * No Authorization header.
         *
         * Let Spring Security decide whether
         * the endpoint is public or protected.
         */

        if (authHeader == null
                || authHeader.isBlank()) {

            System.out.println(
                    "NO AUTHORIZATION HEADER"
            );

            filterChain.doFilter(
                    request,
                    response
            );

            return;
        }


        // =====================================================
        // BEARER TOKEN
        // =====================================================

        if (!authHeader.startsWith(
                "Bearer ")) {

            System.out.println(
                    "INVALID AUTHORIZATION HEADER"
            );

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.setContentType(
                    "application/json"
            );

            response.getWriter().write(
                    """
                    {
                        "success": false,
                        "message": "Invalid Authorization header."
                    }
                    """
            );

            return;
        }


        String token =
                authHeader.substring(7).trim();


        if (token.isBlank()) {

            System.out.println(
                    "EMPTY JWT TOKEN"
            );

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.setContentType(
                    "application/json"
            );

            response.getWriter().write(
                    """
                    {
                        "success": false,
                        "message": "JWT token is missing."
                    }
                    """
            );

            return;
        }


        try {


            // =================================================
            // EXTRACT USERNAME
            // =================================================

            String username =
                    jwtService.extractUsername(
                            token
                    );


            System.out.println(
                    "JWT USERNAME: "
                            + username
            );


            if (username == null
                    || username.isBlank()) {

                sendUnauthorized(
                        response,
                        "Invalid JWT token."
                );

                return;
            }


            // =================================================
            // CHECK EXISTING AUTHENTICATION
            // =================================================

            if (SecurityContextHolder
                    .getContext()
                    .getAuthentication()
                    == null) {


                // =============================================
                // LOAD USER
                // =============================================

                UserDetails userDetails =
                        userDetailsService
                                .loadUserByUsername(
                                        username
                                );


                System.out.println(
                        "USER DETAILS LOADED: "
                                + userDetails
                                        .getUsername()
                );


                System.out.println(
                        "USER AUTHORITIES: "
                                + userDetails
                                        .getAuthorities()
                );


                // =============================================
                // VALIDATE TOKEN
                // =============================================

                boolean valid =
                        jwtService.isTokenValid(
                                token,
                                username
                        );


                System.out.println(
                        "TOKEN VALID: "
                                + valid
                );


                if (!valid) {

                    sendUnauthorized(
                            response,
                            "JWT token is expired or invalid."
                    );

                    return;
                }


                // =============================================
                // CREATE AUTHENTICATION
                // =============================================

                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(
                                userDetails,
                                null,
                                userDetails
                                        .getAuthorities()
                        );


                authentication.setDetails(
                        new WebAuthenticationDetailsSource()
                                .buildDetails(
                                        request
                                )
                );


                // =============================================
                // SET SECURITY CONTEXT
                // =============================================

                SecurityContextHolder
                        .getContext()
                        .setAuthentication(
                                authentication
                        );


                System.out.println(
                        "AUTHENTICATION NAME: "
                                + SecurityContextHolder
                                        .getContext()
                                        .getAuthentication()
                                        .getName()
                );


                System.out.println(
                        "AUTHENTICATION AUTHORITIES: "
                                + SecurityContextHolder
                                        .getContext()
                                        .getAuthentication()
                                        .getAuthorities()
                );


                System.out.println(
                        "AUTHENTICATION SUCCESS"
                );

            }


        } catch (Exception e) {

            System.out.println(
                    "JWT VALIDATION ERROR: "
                            + e.getClass()
                                    .getName()
            );

            System.out.println(
                    "JWT VALIDATION MESSAGE: "
                            + e.getMessage()
            );


            SecurityContextHolder
                    .clearContext();


            sendUnauthorized(
                    response,
                    "Invalid or expired JWT token."
            );

            return;
        }


        System.out.println(
                "CONTINUING FILTER CHAIN"
        );

        System.out.println(
                "================================="
        );


        filterChain.doFilter(
                request,
                response
        );
    }


    // =====================================================
    // UNAUTHORIZED RESPONSE
    // =====================================================

    private void sendUnauthorized(
            HttpServletResponse response,
            String message)
            throws IOException {


        response.setStatus(
                HttpServletResponse.SC_UNAUTHORIZED
        );


        response.setContentType(
                "application/json"
        );


        response.setCharacterEncoding(
                "UTF-8"
        );


        response.getWriter().write(
                """
                {
                    "success": false,
                    "message": "%s"
                }
                """.formatted(
                        message
                )
        );
    }
}