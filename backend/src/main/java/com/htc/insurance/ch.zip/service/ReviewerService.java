package com.htc.insurance.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.htc.insurance.dao.ClaimsDao;
import com.htc.insurance.dao.ReviewerDao;
import com.htc.insurance.dao.UserDao;
import com.htc.insurance.dto.ReviewerDto;
import com.htc.insurance.entity.Claims;
import com.htc.insurance.entity.Reviewer;
import com.htc.insurance.entity.User;
import com.htc.insurance.mapper.ReviewerMapper;

@Service
public class ReviewerService {

    @Autowired
    private ReviewerDao reviewerDao;

    @Autowired
    private UserDao userDao;

    @Autowired
    private ClaimsDao claimsDao;

    @Autowired
    private ReviewerMapper mapper;


    // =========================================================
    // USER - SAVE REVIEW
    // =========================================================

    public ReviewerDto saveReviewer(
            ReviewerDto reviewerDto) {

        // Get currently logged-in user from JWT
        Authentication authentication =
                SecurityContextHolder
                        .getContext()
                        .getAuthentication();

        if (authentication == null ||
                !authentication.isAuthenticated()) {

            return null;
        }

        String username =
                authentication.getName();

        // Find logged-in user
        User user =
                userDao.getUserByUsername(username);

        // Find claim
        if ((user == null) || (reviewerDto.getClaimNumber() == null)) {
            return null;
        }

        Claims claim =
                claimsDao.getClaimsById(
                        reviewerDto.getClaimNumber());

        if (claim == null) {
            return null;
        }

        // Convert DTO to entity
        Reviewer reviewer =
                mapper.convertReviewerDtoToEntity(
                        reviewerDto);

        // Set relationships
        reviewer.setUser(user);
        reviewer.setClaim(claim);

        // Automatically use logged-in user's name
        reviewer.setName(
                user.getUsername());

        // Set review information
        reviewer.setEmail(
                reviewerDto.getEmail());

        reviewer.setContactNumber(
                reviewerDto.getContactNumber());

        reviewer.setRating(
                reviewerDto.getRating());

        reviewer.setReview(
                reviewerDto.getReview());

        // New reviews start as PENDING
        reviewer.setStatus("PENDING");

        // No admin reply initially
        reviewer.setAdminReply(null);

        // Save
        Reviewer savedReviewer =
                reviewerDao.saveReviewer(
                        reviewer);

        return mapper.convertReviewerEntityToDto(
                savedReviewer);
    }


    // =========================================================
    // ADMIN - GET ALL REVIEWS
    // =========================================================

    public List<ReviewerDto> getAllReviewers() {

        List<Reviewer> reviewers =
                reviewerDao.getAllReviewers();

        List<ReviewerDto> dtoList =
                new ArrayList<>();

        for (Reviewer reviewer : reviewers) {

            ReviewerDto dto =
                    mapper.convertReviewerEntityToDto(
                            reviewer);

            dtoList.add(dto);
        }

        return dtoList;
    }


    // =========================================================
    // ADMIN - GET REVIEW BY ID
    // =========================================================

    public ReviewerDto getReviewerById(
            Long reviewerId) {

        Reviewer reviewer =
                reviewerDao.getReviewerById(
                        reviewerId);

        if (reviewer == null) {
            return null;
        }

        return mapper.convertReviewerEntityToDto(
                reviewer);
    }


    // =========================================================
    // USER - GET MY REVIEWS
    // =========================================================

    public List<ReviewerDto> getMyReviews() {

        List<ReviewerDto> myReviews =
                new ArrayList<>();

        // Get currently logged-in user
        Authentication authentication =
                SecurityContextHolder
                        .getContext()
                        .getAuthentication();

        if (authentication == null ||
                !authentication.isAuthenticated()) {

            return myReviews;
        }

        String username =
                authentication.getName();

        // Find logged-in user
        User user =
                userDao.getUserByUsername(username);

        if (user == null) {
            return myReviews;
        }

        // Get all reviews
        List<Reviewer> allReviews =
                reviewerDao.getAllReviewers();

        // Filter only logged-in user's reviews
        for (Reviewer reviewer : allReviews) {

            if (reviewer.getUser() != null &&
                    reviewer.getUser()
                            .getUserId()
                            .equals(user.getUserId())) {

                ReviewerDto dto =
                        mapper.convertReviewerEntityToDto(
                                reviewer);

                myReviews.add(dto);
            }
        }

        return myReviews;
    }


    // =========================================================
    // ADMIN - UPDATE REVIEW
    // =========================================================

    public ReviewerDto updateReviewer(
            Long reviewerId,
            ReviewerDto reviewerDto) {

        Reviewer existingReviewer =
                reviewerDao.getReviewerById(
                        reviewerId);

        if (existingReviewer == null) {
            return null;
        }

        Reviewer reviewer =
                mapper.convertReviewerDtoToEntity(
                        reviewerDto);

        // Keep original ID
        reviewer.setReviewerId(
                reviewerId);

        // Keep original user
        reviewer.setUser(
                existingReviewer.getUser());

        // Keep original claim
        reviewer.setClaim(
                existingReviewer.getClaim());

        // Keep existing admin reply
        reviewer.setAdminReply(
                existingReviewer.getAdminReply());

        // Keep existing status
        reviewer.setStatus(
                existingReviewer.getStatus());

        Reviewer updatedReviewer =
                reviewerDao.updateReviewer(
                        reviewer);

        return mapper.convertReviewerEntityToDto(
                updatedReviewer);
    }


    // =========================================================
    // ADMIN - REPLY TO REVIEW
    // =========================================================

    public ReviewerDto replyToReviewer(
            Long reviewerId,
            String reply) {

        Reviewer reviewer =
                reviewerDao.getReviewerById(
                        reviewerId);

        if (reviewer == null) {
            return null;
        }

        // Save admin reply
        reviewer.setAdminReply(
                reply);

        // Change status
        reviewer.setStatus(
                "REPLIED");

        // Update database
        Reviewer updatedReviewer =
                reviewerDao.updateReviewer(
                        reviewer);

        return mapper.convertReviewerEntityToDto(
                updatedReviewer);
    }


    // =========================================================
    // ADMIN - DELETE REVIEW
    // =========================================================

    public void deleteReviewer(
            Long reviewerId) {

        reviewerDao.deleteReviewer(
                reviewerId);
    }
}