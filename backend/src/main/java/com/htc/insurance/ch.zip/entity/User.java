package com.htc.insurance.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "users")
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    private String username;

    private String password;

    private String role;

    private Boolean isActive;

    private LocalDateTime createdAt;

    private LocalDateTime expiryDate;

    private String contactNumber;

    private String occupation;

    private Double income;

    private String aadharNumber;

    private String bankName;

    private String accountNumber;

    private String ifscCode;

    @OneToMany(mappedBy = "user")
    private List<Reviewer> reviewers;
}