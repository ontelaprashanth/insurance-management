package com.htc.insurance.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class PaymentOrderResponse {

    private String orderId;

    private String keyId;

    private BigDecimal amount;

    private String currency;

    private String receipt;

    public PaymentOrderResponse(
            String orderId,
            String keyId,
            BigDecimal amount,
            String currency,
            String receipt) {

        this.orderId = orderId;
        this.keyId = keyId;
        this.amount = amount;
        this.currency = currency;
        this.receipt = receipt;
    }
}