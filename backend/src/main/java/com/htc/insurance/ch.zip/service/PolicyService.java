package com.htc.insurance.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.htc.insurance.dao.PolicyDao;
import com.htc.insurance.dao.PolicyHolderDao;
import com.htc.insurance.dto.PolicyDto;
import com.htc.insurance.entity.Policy;
import com.htc.insurance.entity.PolicyHolder;
import com.htc.insurance.mapper.PolicyMapper;

@Service
public class PolicyService {

    @Autowired
    private PolicyDao policyDao;

    @Autowired
    private PolicyHolderDao policyHolderDao;

    @Autowired
    private PolicyMapper mapper;


    // =========================
    // SAVE POLICY
    // =========================

    public PolicyDto savePolicy(PolicyDto policyDto) {

        if (policyDto == null) {
            throw new RuntimeException("Policy data is required.");
        }

        if (policyDto.getPolicyHolderId() == null) {
            throw new RuntimeException("Policy holder is required.");
        }

        if (policyDto.getStartDate() == null) {
            throw new RuntimeException("Start date is required.");
        }

        if (policyDto.getDurationYears() == null
                || policyDto.getDurationYears() <= 0) {

            throw new RuntimeException(
                    "Valid duration is required."
            );
        }

        PolicyHolder policyHolder =
                policyHolderDao.getPolicyHolderById(
                        policyDto.getPolicyHolderId()
                );

        if (policyHolder == null) {
            throw new RuntimeException(
                    "Policy holder not found."
            );
        }

        LocalDate expiryDate =
                policyDto.getStartDate()
                        .plusYears(policyDto.getDurationYears())
                        .minusDays(1);

        policyDto.setExpiryDate(expiryDate);
        policyDto.setIsActive(true);

        Policy policy =
                mapper.convertPolicyDtoToEntity(policyDto);

        policy.setPolicyHolder(policyHolder);

        Policy savedPolicy =
                policyDao.savePolicy(policy);

        PolicyDto response =
                mapper.convertPolicyEntityToDto(savedPolicy);

        response.setHasClaims(false);

        return response;
    }


    // =========================
    // GET ALL POLICIES
    // =========================

    @Transactional(readOnly = true)
    public List<PolicyDto> getAllPolicies() {

        List<Policy> policies =
                policyDao.getAllPolicies();

        List<PolicyDto> dtoList =
                new ArrayList<>();

        for (Policy policy : policies) {

            PolicyDto dto =
                    mapper.convertPolicyEntityToDto(policy);

            boolean hasClaims =
                    policy.getClaims() != null
                    && !policy.getClaims().isEmpty();

            dto.setHasClaims(hasClaims);

            dtoList.add(dto);
        }

        return dtoList;
    }


    // =========================
    // GET POLICY BY ID
    // =========================

    @Transactional(readOnly = true)
    public PolicyDto getPolicyById(Long policyNumber) {

        Policy policy =
                policyDao.getPolicyById(policyNumber);

        if (policy == null) {
            return null;
        }

        PolicyDto dto =
                mapper.convertPolicyEntityToDto(policy);

        boolean hasClaims =
                policy.getClaims() != null
                && !policy.getClaims().isEmpty();

        dto.setHasClaims(hasClaims);

        return dto;
    }


    // =========================
    // UPDATE POLICY
    // =========================

    public PolicyDto updatePolicy(
            Long policyNumber,
            PolicyDto policyDto) {

        Policy existingPolicy =
                policyDao.getPolicyById(policyNumber);

        if (existingPolicy == null) {
            return null;
        }

        if (policyDto == null) {
            throw new RuntimeException(
                    "Policy data is required."
            );
        }

        if (policyDto.getPolicyHolderId() == null) {
            throw new RuntimeException(
                    "Policy holder is required."
            );
        }

        if (policyDto.getStartDate() == null) {
            throw new RuntimeException(
                    "Start date is required."
            );
        }

        if (policyDto.getDurationYears() == null
                || policyDto.getDurationYears() <= 0) {

            throw new RuntimeException(
                    "Valid duration is required."
            );
        }

        PolicyHolder policyHolder =
                policyHolderDao.getPolicyHolderById(
                        policyDto.getPolicyHolderId()
                );

        if (policyHolder == null) {
            throw new RuntimeException(
                    "Policy holder not found."
            );
        }

        LocalDate expiryDate =
                policyDto.getStartDate()
                        .plusYears(policyDto.getDurationYears())
                        .minusDays(1);

        policyDto.setExpiryDate(expiryDate);

        /*
         * Preserve the existing active/inactive status
         * when updating the policy.
         */
        policyDto.setIsActive(
                existingPolicy.getIsActive()
        );

        Policy policy =
                mapper.convertPolicyDtoToEntity(policyDto);

        policy.setPolicyNumber(policyNumber);
        policy.setPolicyHolder(policyHolder);

        Policy updatedPolicy =
                policyDao.updatePolicy(policy);

        PolicyDto response =
                mapper.convertPolicyEntityToDto(
                        updatedPolicy
                );

        boolean hasClaims =
                existingPolicy.getClaims() != null
                && !existingPolicy.getClaims().isEmpty();

        response.setHasClaims(hasClaims);

        return response;
    }


    // =========================
    // DELETE POLICY
    // =========================

    public void deletePolicy(Long policyNumber) {

        Policy policy =
                policyDao.getPolicyById(policyNumber);

        if (policy == null) {
            throw new RuntimeException(
                    "Policy not found: " + policyNumber
            );
        }

        /*
         * Do not physically delete a policy that
         * already has claims.
         */
        if (policy.getClaims() != null
                && !policy.getClaims().isEmpty()) {

            throw new RuntimeException(
                    "Policy cannot be deleted because claims are associated with this policy."
            );
        }

        policyDao.deletePolicy(policyNumber);
    }


    public PolicyDto activatePolicy(Long policyNumber) {

        Policy policy =
            policyDao.getPolicyById(policyNumber);

        if (policy == null) {
            throw new RuntimeException(
                "Policy not found: " + policyNumber
            );
        }

        policy.setIsActive(true);

        Policy updated =
            policyDao.updatePolicy(policy);

        PolicyDto response =
            mapper.convertPolicyEntityToDto(updated);

        boolean hasClaims =
            updated.getClaims() != null &&
            !updated.getClaims().isEmpty();

        response.setHasClaims(hasClaims);

        return response;
    }


    @Transactional(readOnly = true)
    public List<PolicyDto> getPoliciesByUsername(
            String username) {

        PolicyHolder policyHolder =
                policyHolderDao.getPolicyHolderByUsername(
                        username);

        if (policyHolder == null) {
            return new ArrayList<>();
        }

        List<Policy> policies =
                policyHolder.getPolicies();

        List<PolicyDto> dtoList =
                new ArrayList<>();

        if (policies == null) {
            return dtoList;
        }

        for (Policy policy : policies) {

            PolicyDto dto =
                    mapper.convertPolicyEntityToDto(
                            policy);

            boolean hasClaims =
                    policy.getClaims() != null
                    && !policy.getClaims().isEmpty();

            dto.setHasClaims(hasClaims);

            dtoList.add(dto);
        }

        return dtoList;
    }


    // =========================
    // DEACTIVATE POLICY
    // =========================

    public PolicyDto deactivatePolicy(Long policyNumber) {

        Policy policy =
                policyDao.getPolicyById(policyNumber);

        if (policy == null) {
            throw new RuntimeException(
                    "Policy not found: " + policyNumber
            );
        }

        /*
         * Instead of deleting a policy with claims,
         * mark it inactive.
         */
        policy.setIsActive(false);

        Policy updatedPolicy =
                policyDao.updatePolicy(policy);

        PolicyDto response =
                mapper.convertPolicyEntityToDto(
                        updatedPolicy
                );

        boolean hasClaims =
                updatedPolicy.getClaims() != null
                && !updatedPolicy.getClaims().isEmpty();

        response.setHasClaims(hasClaims);

        return response;
    }
    
 // =========================================================
 // GET AVAILABLE POLICIES FOR USER
 // =========================================================

 @Transactional(readOnly = true)
 public List<PolicyDto> getAvailablePolicies() {

     List<Policy> policies =
             policyDao.getAllPolicies();

     List<PolicyDto> dtoList =
             new ArrayList<>();

     for (Policy policy : policies) {

         // Only active policies can be purchased
         if (!Boolean.TRUE.equals(policy.getIsActive())) {
             continue;
         }

         PolicyDto dto =
                 mapper.convertPolicyEntityToDto(policy);

         boolean hasClaims =
                 policy.getClaims() != null
                 && !policy.getClaims().isEmpty();

         dto.setHasClaims(hasClaims);

         dtoList.add(dto);
     }

     return dtoList;
 }
}