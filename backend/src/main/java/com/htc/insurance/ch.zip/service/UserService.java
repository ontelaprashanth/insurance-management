package com.htc.insurance.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.htc.insurance.dao.UserDao;
import com.htc.insurance.dto.UserDto;
import com.htc.insurance.entity.User;
import com.htc.insurance.mapper.UserMapper;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    @Autowired
    private UserMapper mapper;

    @Autowired
    private PasswordEncoder passwordEncoder;


    // ==============================
    // SAVE USER
    // ==============================

    public UserDto saveUser(UserDto userDto) {

        User user =
                mapper.convertUserDtoToUserEntity(userDto);

        // ==============================
        // DEFAULT ROLE
        // ==============================

        // Every newly registered user
        // will automatically become USER
        user.setRole("USER");


        // ==============================
        // CREATE DATE
        // ==============================

        LocalDateTime createdAt =
                LocalDateTime.now();

        user.setCreatedAt(createdAt);


        // ==============================
        // EXPIRY DATE
        // ==============================

        // Expiry after 1 year
        LocalDateTime expiryDate =
                createdAt.plusYears(1);

        user.setExpiryDate(expiryDate);


        // ==============================
        // ACTIVE STATUS
        // ==============================

        user.setIsActive(true);


        // ==============================
        // ENCRYPT PASSWORD
        // ==============================

        user.setPassword(
                passwordEncoder.encode(
                        user.getPassword()
                )
        );


        // ==============================
        // SAVE
        // ==============================

        User savedUser =
                userDao.saveUser(user);

        return mapper.convertUserEntityToUserDto(
                savedUser
        );
    }


    // ==============================
    // CHECK ACTIVE STATUS
    // ==============================

    private void updateActiveStatus(User user) {

        if (user.getExpiryDate() == null) {

            user.setIsActive(false);

            return;
        }

        LocalDateTime now =
                LocalDateTime.now();

        if (now.isAfter(user.getExpiryDate())) {

            user.setIsActive(false);

        } else {

            user.setIsActive(true);
        }
    }


    // ==============================
    // GET USER
    // ==============================

    public UserDto getUserById(Long userId) {

        User user =
                userDao.getUserById(userId);

        if (user == null) {
            return null;
        }

        updateActiveStatus(user);

        return mapper.convertUserEntityToUserDto(
                user
        );
    }


    // ==============================
    // GET ALL USERS
    // ==============================

    public List<UserDto> getAllUsers() {

        List<User> users =
                userDao.getAllUsers();

        List<UserDto> dtoList =
                new ArrayList<>();

        for (User user : users) {

            updateActiveStatus(user);

            UserDto dto =
                    mapper.convertUserEntityToUserDto(
                            user
                    );

            dtoList.add(dto);
        }

        return dtoList;
    }


    // ==============================
    // UPDATE USER
    // ==============================

    public UserDto updateUser(
            Long userId,
            UserDto userDto) {

        User existingUser =
                userDao.getUserById(userId);

        if (existingUser == null) {
            return null;
        }

        User user =
                mapper.convertUserDtoToUserEntity(
                        userDto
                );

        user.setUserId(userId);


        // ==============================
        // CREATED DATE
        // ==============================

        // Do NOT allow changing created date
        user.setCreatedAt(
                existingUser.getCreatedAt()
        );


        // ==============================
        // EXPIRY DATE
        // ==============================

        // Do NOT allow changing expiry date
        user.setExpiryDate(
                existingUser.getExpiryDate()
        );



        updateActiveStatus(existingUser);

        user.setIsActive(
                existingUser.getIsActive()
        );



        user.setRole(
                existingUser.getRole()
        );




        if (user.getPassword() != null &&
                !user.getPassword().isBlank()) {

            user.setPassword(
                    passwordEncoder.encode(
                            user.getPassword()
                    )
            );

        } else {

            user.setPassword(
                    existingUser.getPassword()
            );
        }




        User updatedUser =
                userDao.updateUser(user);

        return mapper.convertUserEntityToUserDto(
                updatedUser
        );
    }




    public void deleteUser(Long userId) {

        userDao.deleteUser(userId);
    }
}