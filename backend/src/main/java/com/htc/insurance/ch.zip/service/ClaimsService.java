package com.htc.insurance.service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.htc.insurance.dao.ClaimsDao;
import com.htc.insurance.dao.PolicyDao;
import com.htc.insurance.dao.UserDao;
import com.htc.insurance.dto.ClaimDecisionDto;
import com.htc.insurance.dto.ClaimsDto;
import com.htc.insurance.entity.ClaimStatus;
import com.htc.insurance.entity.Claims;
import com.htc.insurance.entity.Policy;
import com.htc.insurance.entity.PolicyHolder;
import com.htc.insurance.entity.User;
import com.htc.insurance.mapper.ClaimsMapper;

@Service
public class ClaimsService {

    @Autowired
    private ClaimsDao claimsDao;

    @Autowired
    private PolicyDao policyDao;

    @Autowired
    private UserDao userDao;

    @Autowired
    private ClaimsMapper claimsMapper;


    // =========================================================
    // USER + ADMIN
    // SUBMIT NEW CLAIM
    // =========================================================
    public ClaimsDto saveClaims(
            ClaimsDto claimsDto,
            Authentication authentication) {

        if (authentication == null ||
                authentication.getName() == null) {

            throw new RuntimeException(
                    "User authentication required"
            );
        }

        String username =
                authentication.getName();

        User user =
                userDao.getUserByUsername(
                        username
                );

        if (user == null) {
            throw new RuntimeException(
                    "Logged-in user not found"
            );
        }

        Policy policy =
                policyDao.getPolicyById(
                        claimsDto.getPolicyNumber()
                );

        if (policy == null) {
            throw new RuntimeException(
                    "Policy not found"
            );
        }

        /*
         * Verify that selected policy belongs
         * to the logged-in user.
         */
        PolicyHolder policyHolder =
                policy.getPolicyHolder();

        if (policyHolder == null ||
                policyHolder.getUser() == null ||
                !policyHolder.getUser()
                        .getUserId()
                        .equals(user.getUserId())) {

            throw new RuntimeException(
                    "You can only raise a claim against your own policy"
            );
        }

        /*
         * Convert DTO -> Entity
         */
        Claims claims =
                claimsMapper.convertClaimsDtoToEntity(
                        claimsDto
                );

        /*
         * Connect policy
         */
        claims.setPolicy(policy);

        /*
         * Automatically set claim date
         */
        claims.setClaimDate(
                LocalDate.now()
        );

        /*
         * Every new claim starts as PENDING
         */
        claims.setStatus(
                ClaimStatus.PENDING
        );

        /*
         * Clear admin decision fields
         */
        claims.setApprovedAmount(null);
        claims.setAdminRemarks(null);
        claims.setRejectionReason(null);
        claims.setReviewedDate(null);

        Claims savedClaims =
                claimsDao.saveClaims(
                        claims
                );

        return claimsMapper.convertClaimsEntityToDto(
                savedClaims
        );
    }


    // =========================================================
    // ADMIN - GET ALL CLAIMS
    // =========================================================
    public List<ClaimsDto> getAllClaims() {

        List<Claims> claimsList =
                claimsDao.getAllClaims();

        return claimsList
                .stream()
                .map(
                    claimsMapper::convertClaimsEntityToDto
                )
                .collect(
                    Collectors.toList()
                );
    }


    // =========================================================
    // USER - GET MY CLAIMS
    // =========================================================
    public List<ClaimsDto> getMyClaims(
            Authentication authentication) {

        String username =
                authentication.getName();

        User user =
                userDao.getUserByUsername(
                        username
                );

        if (user == null) {
            throw new RuntimeException(
                    "Logged-in user not found"
            );
        }

        List<Claims> allClaims =
                claimsDao.getAllClaims();

        return allClaims
                .stream()
                .filter(claim -> {

                    Policy policy =
                            claim.getPolicy();

                    if (policy == null) {
                        return false;
                    }

                    PolicyHolder holder =
                            policy.getPolicyHolder();

                    if (holder == null ||
                            holder.getUser() == null) {
                        return false;
                    }

                    return holder
                            .getUser()
                            .getUserId()
                            .equals(user.getUserId());
                })
                .map(
                    claimsMapper::convertClaimsEntityToDto
                )
                .collect(
                    Collectors.toList()
                );
    }


    // =========================================================
    // USER + ADMIN - GET CLAIM BY ID
    // =========================================================
    public ClaimsDto getClaimsById(
            Long claimNumber,
            Authentication authentication) {

        Claims claim =
                claimsDao.getClaimsById(
                        claimNumber
                );

        if (claim == null) {
            return null;
        }

        /*
         * Admin can view any claim.
         */
        boolean isAdmin =
                authentication.getAuthorities()
                        .stream()
                        .anyMatch(
                            authority ->
                                authority.getAuthority()
                                    .equals("ROLE_ADMIN")
                        );

        if (isAdmin) {
            return claimsMapper
                    .convertClaimsEntityToDto(
                            claim
                    );
        }

        /*
         * USER can only view own claim.
         */
        String username =
                authentication.getName();

        User user =
                userDao.getUserByUsername(
                        username
                );

        if (user == null) {
            throw new RuntimeException(
                    "Logged-in user not found"
            );
        }

        Policy policy =
                claim.getPolicy();

        if (policy == null ||
                policy.getPolicyHolder() == null ||
                policy.getPolicyHolder().getUser() == null) {

            throw new RuntimeException(
                    "Claim ownership could not be verified"
            );
        }

        Long ownerId =
                policy.getPolicyHolder()
                        .getUser()
                        .getUserId();

        if (!ownerId.equals(user.getUserId())) {

            throw new RuntimeException(
                    "You are not authorized to view this claim"
            );
        }

        return claimsMapper
                .convertClaimsEntityToDto(
                        claim
                );
    }


    // =========================================================
    // ADMIN - UPDATE CLAIM
    // =========================================================
    public ClaimsDto updateClaims(
            Long claimNumber,
            ClaimsDto claimsDto) {

        Claims existingClaims =
                claimsDao.getClaimsById(
                        claimNumber
                );

        if (existingClaims == null) {
            return null;
        }

        Claims claims =
                claimsMapper.convertClaimsDtoToEntity(
                        claimsDto
                );

        claims.setClaimNumber(
                claimNumber
        );

        Policy policy =
                policyDao.getPolicyById(
                        claimsDto.getPolicyNumber()
                );

        if (policy == null) {
            return null;
        }

        claims.setPolicy(
                policy
        );

        /*
         * Preserve original submission information.
         */
        claims.setClaimDate(
                existingClaims.getClaimDate()
        );

        claims.setStatus(
                existingClaims.getStatus()
        );

        claims.setApprovedAmount(
                existingClaims.getApprovedAmount()
        );

        claims.setAdminRemarks(
                existingClaims.getAdminRemarks()
        );

        claims.setRejectionReason(
                existingClaims.getRejectionReason()
        );

        claims.setReviewedDate(
                existingClaims.getReviewedDate()
        );

        Claims updatedClaims =
                claimsDao.updateClaims(
                        claims
                );

        return claimsMapper.convertClaimsEntityToDto(
                updatedClaims
        );
    }


    // =========================================================
    // ADMIN - APPROVE CLAIM
    // =========================================================
    public ClaimsDto approveClaim(
            Long claimNumber,
            ClaimDecisionDto decisionDto) {

        Claims claim =
                claimsDao.getClaimsById(
                        claimNumber
                );

        if (claim == null) {
            return null;
        }

        /*
         * Claim becomes APPROVED.
         */
        claim.setStatus(
                ClaimStatus.APPROVED
        );

        /*
         * Store approved amount.
         */
        claim.setApprovedAmount(
                decisionDto.getApprovedAmount()
        );

        /*
         * Store admin remarks.
         */
        claim.setAdminRemarks(
                decisionDto.getAdminRemarks()
        );

        /*
         * Clear rejection reason.
         */
        claim.setRejectionReason(
                null
        );

        /*
         * Store review date.
         */
        claim.setReviewedDate(
                LocalDate.now()
        );

        Claims updatedClaim =
                claimsDao.updateClaims(
                        claim
                );

        return claimsMapper.convertClaimsEntityToDto(
                updatedClaim
        );
    }


    // =========================================================
    // ADMIN - REJECT CLAIM
    // =========================================================
    public ClaimsDto rejectClaim(
            Long claimNumber,
            ClaimDecisionDto decisionDto) {

        Claims claim =
                claimsDao.getClaimsById(
                        claimNumber
                );

        if (claim == null) {
            return null;
        }

        /*
         * Claim becomes REJECTED.
         */
        claim.setStatus(
                ClaimStatus.REJECTED
        );

        /*
         * Rejected claims have no approved amount.
         */
        claim.setApprovedAmount(
                null
        );

        /*
         * Store admin remarks.
         */
        claim.setAdminRemarks(
                decisionDto.getAdminRemarks()
        );

        /*
         * Store rejection reason.
         */
        claim.setRejectionReason(
                decisionDto.getRejectionReason()
        );

        /*
         * Store review date.
         */
        claim.setReviewedDate(
                LocalDate.now()
        );

        Claims updatedClaim =
                claimsDao.updateClaims(
                        claim
                );

        return claimsMapper.convertClaimsEntityToDto(
                updatedClaim
        );
    }


    // =========================================================
    // ADMIN - DELETE CLAIM
    // =========================================================
    public void deleteClaims(
            Long claimNumber) {

        claimsDao.deleteClaims(
                claimNumber
        );
    }
}