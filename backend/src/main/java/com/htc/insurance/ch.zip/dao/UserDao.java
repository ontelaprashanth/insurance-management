package com.htc.insurance.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.htc.insurance.entity.User;
import com.htc.insurance.repository.UserRepository;

@Repository
public class UserDao {

    @Autowired
    private UserRepository repository;

    public User saveUser(User user) {

        return repository.save(user);
    }

    public User getUserById(Long userId) {

        return repository.findById(userId)
                .orElse(null);
    }

    public List<User> getAllUsers() {

        return repository.findAll();
    }

    public User updateUser(User user) {

        return repository.save(user);
    }

    public void deleteUser(Long userId) {

        repository.deleteById(userId);
    }

    public User getUserByUsername(String username) {

        return repository.findByUsername(username)
                .orElse(null);
    }
}