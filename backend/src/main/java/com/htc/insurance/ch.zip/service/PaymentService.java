package com.htc.insurance.service;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.htc.insurance.dto.PaymentOrderRequest;
import com.htc.insurance.dto.PaymentOrderResponse;
import com.htc.insurance.dto.PaymentVerificationRequest;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;

@Service
public class PaymentService {

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    @Value("${razorpay.currency:INR}")
    private String currency;

    public PaymentOrderResponse createOrder(
            PaymentOrderRequest request) throws Exception {

        if (request == null) {
            throw new RuntimeException(
                    "Payment request is required."
            );
        }

        if (request.getAmount() == null
                || request.getAmount()
                        .compareTo(BigDecimal.ZERO) <= 0) {

            throw new RuntimeException(
                    "Valid payment amount is required."
            );
        }

        RazorpayClient razorpayClient =
                new RazorpayClient(
                        razorpayKeyId,
                        razorpayKeySecret
                );

        long amountInPaise =
                request.getAmount()
                        .multiply(BigDecimal.valueOf(100))
                        .longValueExact();

        String receipt =
                request.getReceipt();

        if (receipt == null
                || receipt.trim().isEmpty()) {

            receipt =
                    "INSX_"
                    + UUID.randomUUID()
                            .toString()
                            .replace("-", "")
                            .substring(0, 12)
                            .toUpperCase();
        }

        JSONObject orderRequest =
                new JSONObject();

        orderRequest.put(
                "amount",
                amountInPaise
        );

        orderRequest.put(
                "currency",
                currency
        );

        orderRequest.put(
                "receipt",
                receipt
        );

        Order order =
                razorpayClient.orders.create(
                        orderRequest
                );

        String orderId =
                order.get("id");

        return new PaymentOrderResponse(
                orderId,
                razorpayKeyId,
                request.getAmount(),
                currency,
                receipt
        );
    }

    public boolean verifyPayment(
            PaymentVerificationRequest request)
            throws Exception {

        if (request == null
                || request.getRazorpayOrderId() == null
                || request.getRazorpayPaymentId() == null
                || request.getRazorpaySignature() == null) {

            return false;
        }

        String data =
                request.getRazorpayOrderId()
                + "|"
                + request.getRazorpayPaymentId();

        String generatedSignature =
                generateHmacSha256(
                        data,
                        razorpayKeySecret
                );

        return MessageDigest.isEqual(
                generatedSignature.getBytes(
                        StandardCharsets.UTF_8
                ),
                request.getRazorpaySignature()
                        .getBytes(
                                StandardCharsets.UTF_8
                        )
        );
    }

    private String generateHmacSha256(
            String data,
            String secret) throws Exception {

        Mac mac =
                Mac.getInstance("HmacSHA256");

        SecretKeySpec secretKey =
                new SecretKeySpec(
                        secret.getBytes(
                                StandardCharsets.UTF_8
                        ),
                        "HmacSHA256"
                );

        mac.init(secretKey);

        byte[] hash =
                mac.doFinal(
                        data.getBytes(
                                StandardCharsets.UTF_8
                        )
                );

        StringBuilder result =
                new StringBuilder();

        for (byte b : hash) {
            result.append(
                    String.format(
                            "%02x",
                            b
                    )
            );
        }

        return result.toString();
    }
}