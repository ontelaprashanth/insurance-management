package com.htc.insurance.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.htc.insurance.dao.PolicyHolderDao;
import com.htc.insurance.dto.PolicyHolderDto;
import com.htc.insurance.entity.PolicyHolder;
import com.htc.insurance.mapper.PolicyHolderMapper;

@Service
public class PolicyHolderService {

    @Autowired
    private PolicyHolderDao policyHolderDao;

    @Autowired
    private PolicyHolderMapper mapper;

    // ==========================================
    // SAVE POLICY HOLDER
    // ==========================================

    public PolicyHolderDto savePolicyHolder(
            PolicyHolderDto policyHolderDto) {

        PolicyHolder policyHolder =
                mapper.convertPolicyHolderDtoToEntity(
                        policyHolderDto);

        PolicyHolder policyHolderDb =
                policyHolderDao.savePolicyHolder(
                        policyHolder);

        return mapper.convertPolicyHolderEntityToDto(
                policyHolderDb);
    }

    // ==========================================
    // GET ALL POLICY HOLDERS
    // ==========================================

    public List<PolicyHolderDto> getAllPolicyHolders() {

        List<PolicyHolder> policyHolders =
                policyHolderDao.getAllPolicyHolders();

        List<PolicyHolderDto> dtoList =
                new ArrayList<>();

        for (PolicyHolder policyHolder : policyHolders) {

            PolicyHolderDto dto =
                    mapper.convertPolicyHolderEntityToDto(
                            policyHolder);

            dtoList.add(dto);
        }

        return dtoList;
    }

    // ==========================================
    // GET POLICY HOLDER BY ID
    // ==========================================

    public PolicyHolderDto getPolicyHolderById(
            Long policyHolderId) {

        PolicyHolder policyHolder =
                policyHolderDao.getPolicyHolderById(
                        policyHolderId);

        if (policyHolder == null) {
            return null;
        }

        return mapper.convertPolicyHolderEntityToDto(
                policyHolder);
    }

    // ==========================================
    // UPDATE POLICY HOLDER
    // ==========================================

    public PolicyHolderDto updatePolicyHolder(
            Long policyHolderId,
            PolicyHolderDto policyHolderDto) {

        PolicyHolder existingPolicyHolder =
                policyHolderDao.getPolicyHolderById(
                        policyHolderId);

        if (existingPolicyHolder == null) {
            return null;
        }

        PolicyHolder policyHolder =
                mapper.convertPolicyHolderDtoToEntity(
                        policyHolderDto);

        policyHolder.setPolicyHolderId(
                policyHolderId);

        PolicyHolder updatedPolicyHolder =
                policyHolderDao.updatePolicyHolder(
                        policyHolder);

        return mapper.convertPolicyHolderEntityToDto(
                updatedPolicyHolder);
    }

    // ==========================================
    // DELETE POLICY HOLDER
    // ==========================================

    public void deletePolicyHolder(
            Long policyHolderId) {

        policyHolderDao.deletePolicyHolder(
                policyHolderId);
    }

    // ==========================================
    // GET LOGGED-IN USER'S POLICY HOLDER
    // ==========================================

    public PolicyHolder getPolicyHolderByUsername(
            String username) {

        return policyHolderDao
                .getPolicyHolderByUsername(username);
    }
}