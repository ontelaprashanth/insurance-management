package com.htc.insurance.security;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.htc.insurance.dao.UserDao;
import com.htc.insurance.entity.User;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserDao userDao;

    public CustomUserDetailsService(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        System.out.println("=================================");
        System.out.println("LOGIN USERNAME RECEIVED: " + username);

        User user = userDao.getUserByUsername(username);

        if (user == null) {

            System.out.println("USER NOT FOUND");

            throw new UsernameNotFoundException(
                    "User not found: " + username
            );
        }

        System.out.println("USER FOUND: " + user.getUsername());
        System.out.println("DATABASE ROLE: " + user.getRole());
        System.out.println("ACTIVE: " + user.getIsActive());
        System.out.println("PASSWORD HASH EXISTS: "
                + (user.getPassword() != null));

        UserDetails userDetails =
                org.springframework.security.core.userdetails.User
                        .withUsername(user.getUsername())
                        .password(user.getPassword())
                        .roles(user.getRole())
                        .disabled(
                                !Boolean.TRUE.equals(
                                        user.getIsActive()
                                )
                        )
                        .build();

        System.out.println(
                "SPRING AUTHORITIES: "
                        + userDetails.getAuthorities()
        );

        System.out.println("=================================");

        return userDetails;
    }
}