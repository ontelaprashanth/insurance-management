package com.htc.insurance.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class PurchasePolicyDto {

    private Long purchaseId;

    private Long policyNumber;

    private String username;

    private String coveredTypes;

    private Integer durationYears;

    // Policy dates
    private LocalDate startDate;
    private LocalDate expiryDate;

    private BigDecimal coverageAmount;

    private String nomineeName;
    private String nomineeRelation;
    private String nomineeContact;

    private String paymentMethod;

    private BigDecimal basePremium;
    private BigDecimal discountAmount;
    private BigDecimal taxableAmount;
    private BigDecimal gstRate;
    private BigDecimal gstAmount;
    private BigDecimal totalPremium;

    private String paymentStatus;
    private String transactionId;
    private String razorpayOrderId;
    private String razorpayPaymentId;

    private LocalDate paymentDate;
    private LocalDateTime paymentDateTime;

    private LocalDate purchaseDate;
    private LocalDateTime createdAt;

    private String refundStatus;
    private String refundId;
    private BigDecimal refundAmount;
    private String refundReason;
    private LocalDateTime refundDateTime;

    private LocalDateTime refundDeadline;
    private Boolean refundEligible;
}