package com.htc.insurance.mapper;

import org.springframework.stereotype.Component;

import com.htc.insurance.dto.UserDto;
import com.htc.insurance.entity.User;

@Component
public class UserMapper {

    public User convertUserDtoToUserEntity(
            UserDto dto) {

        User user = new User();

        user.setUserId(dto.getUserId());
        user.setUsername(dto.getUsername());
        user.setPassword(dto.getPassword());

        // Role
        user.setRole(dto.getRole());

        user.setIsActive(dto.getIsActive());
        user.setCreatedAt(dto.getCreatedAt());
        user.setExpiryDate(dto.getExpiryDate());
        user.setContactNumber(dto.getContactNumber());
        user.setOccupation(dto.getOccupation());
        user.setIncome(dto.getIncome());
        user.setAadharNumber(dto.getAadharNumber());
        user.setBankName(dto.getBankName());
        user.setAccountNumber(dto.getAccountNumber());
        user.setIfscCode(dto.getIfscCode());

        return user;
    }


    public UserDto convertUserEntityToUserDto(
            User user) {

        UserDto dto = new UserDto();

        dto.setUserId(user.getUserId());
        dto.setUsername(user.getUsername());

        // Do not return password
        dto.setPassword(null);

        // Role
        dto.setRole(user.getRole());

        dto.setIsActive(user.getIsActive());

        dto.setCreatedAt(user.getCreatedAt());

        dto.setExpiryDate(user.getExpiryDate());

        dto.setContactNumber(user.getContactNumber());
        dto.setOccupation(user.getOccupation());
        dto.setIncome(user.getIncome());
        dto.setAadharNumber(user.getAadharNumber());
        dto.setBankName(user.getBankName());
        dto.setAccountNumber(user.getAccountNumber());
        dto.setIfscCode(user.getIfscCode());

        return dto;
    }
}